# EA FC 27 — World Player Atlas & Dataset

Interactive dashboard and full player-ratings dataset for EA SPORTS FC 27 — 19,789 players across 164 countries and 702 clubs, pulled from EA's public ratings API.

## Live Demo

`index.html` is a single self-contained file — data, charts, and map are all bundled in, no build step required. Open it directly in Chrome, Edge, or any modern browser.

To host it as a shareable link, enable **GitHub Pages** for this repo (Settings → Pages → Deploy from branch → `main`, root folder). It will publish at:

```
https://lakshmikanth11.github.io/EA_FC_ANALYSIS/
```

## Features

- Filter all 19,789 players by position, gender, continent, and rating tier (85+ Superstars down to <70 Emerging)
- Interactive world map — click a country to isolate its players and stats
- Head-to-head player comparison with radar charts across 16 attributes (e.g. quick presets like Mbappé vs Haaland)
- Doughnut and bar charts for position, league, and nationality breakdowns, each clickable as a filter

## Repository Structure

```
EA_FC_ANALYSIS/
├── index.html                                 # Self-contained dashboard — open directly or serve via GitHub Pages
├── README.md
└── EA_FC_PLAYERS_DATASET_AND_ DASHBOARD/       # Source project: raw data, build scripts, template
    ├── dashboard.html                         # Same dashboard as index.html
    ├── build.ps1                              # Recompiles dashboard.html from template + data
    ├── src/
    │   └── dashboard_template.html            # Modular HTML/CSS/JS template
    ├── data/
    │   ├── players.csv                        # Full raw dataset (19,789 rows × 60 columns)
    │   ├── country_data.json                  # Aggregated national stats
    │   ├── players_search.json                # Search & comparison index
    │   ├── top_clubs_rating.json              # Club ratings, squads, star players
    │   └── world-110m.json                    # World map geography (TopoJSON)
    ├── scripts/                                # PowerShell: players.csv → JSON/reports
    │   ├── extract_data.ps1
    │   ├── extract_detailed.ps1
    │   ├── extract_players_json.ps1
    │   ├── extract_clubs_rating.ps1
    │   └── build_dashboard.ps1
    └── reports/                                # Plain-text summary stats
        ├── summary.txt
        ├── nationality_counts.txt
        ├── position_counts.txt
        ├── league_counts.txt
        ├── avg_rating_by_country.txt
        └── gender_by_country.txt
```

## Dataset

All 19,789 players from EA's public ratings API, snapshot taken 2026-09-12. One row per player in `data/players.csv` (60 columns), covering:

- The six card facets (pace, shooting, passing, dribbling, defending, physicality)
- 34 detailed sub-attributes behind those facets
- Goalkeeping stats for the 2,204 goalkeepers
- `playstyles` — comma-separated PlayStyles (~41% of players have at least one); a PlayStyle+ keeps EA's trailing `+`, e.g. `Finesse Shot+`

Both divisions are included. `gender` separates Men's Football (17,849 players) from Women's Football (1,940 players):

```python
women = df[df.gender == "Women's Football"]
```

<details>
<summary><b>Full column schema (60 columns)</b></summary>

| Column | Description |
|---|---|
| `player_id` | EA's numeric player id, stable across snapshots. |
| `common_name` | Single display name EA gives some players. Blank for most. |
| `first_name` | First name. |
| `last_name` | Last name. |
| `overall_rating` | Overall card rating, 1-99. |
| `position` | Primary position, EA's short label (GK, CB, ST, ...). |
| `alternate_positions` | Other playable positions, space separated. Blank if none. |
| `club` | Club the player plays for. |
| `league` | League the club plays in. |
| `nationality` | Country EA lists for the player. |
| `gender` | EA's division label: "Men's Football" or "Women's Football". |
| `preferred_foot` | Right or Left. |
| `skill_moves` | Skill moves star rating, 1-5. |
| `weak_foot` | Weak foot star rating, 1-5. |
| `height_cm` | Height in centimeters (if populated). |
| `weight_kg` | Weight in kilograms (if populated). |
| `birthdate` | Birthdate as an ISO 8601 date (YYYY-MM-DD). |
| `playstyles` | PlayStyles, comma separated. A PlayStyle+ keeps EA's trailing +. |
| `pace` | Pace card facet, 1-99. |
| `shooting` | Shooting card facet, 1-99. |
| `passing` | Passing card facet, 1-99. |
| `dribbling` | Dribbling card facet, 1-99. |
| `defending` | Defending card facet, 1-99. |
| `physicality` | Physicality card facet, 1-99. |
| `attacking_crossing` | Crossing detailed attribute (attacking group), 1-99. |
| `attacking_finishing` | Finishing detailed attribute (attacking group), 1-99. |
| `attacking_heading_accuracy` | Heading accuracy detailed attribute (attacking group), 1-99. |
| `attacking_short_passing` | Short passing detailed attribute (attacking group), 1-99. |
| `attacking_volleys` | Volleys detailed attribute (attacking group), 1-99. |
| `skill_dribbling` | Dribbling detailed attribute (skill group), 1-99. |
| `skill_curve` | Curve detailed attribute (skill group), 1-99. |
| `skill_fk_accuracy` | Free kick accuracy detailed attribute (skill group), 1-99. |
| `skill_long_passing` | Long passing detailed attribute (skill group), 1-99. |
| `skill_ball_control` | Ball control detailed attribute (skill group), 1-99. |
| `movement_acceleration` | Acceleration detailed attribute (movement group), 1-99. |
| `movement_sprint_speed` | Sprint speed detailed attribute (movement group), 1-99. |
| `movement_agility` | Agility detailed attribute (movement group), 1-99. |
| `movement_reactions` | Reactions detailed attribute (movement group), 1-99. |
| `movement_balance` | Balance detailed attribute (movement group), 1-99. |
| `power_shot_power` | Shot power detailed attribute (power group), 1-99. |
| `power_jumping` | Jumping detailed attribute (power group), 1-99. |
| `power_stamina` | Stamina detailed attribute (power group), 1-99. |
| `power_strength` | Strength detailed attribute (power group), 1-99. |
| `power_long_shots` | Long shots detailed attribute (power group), 1-99. |
| `mentality_aggression` | Aggression detailed attribute (mentality group), 1-99. |
| `mentality_interceptions` | Interceptions detailed attribute (mentality group), 1-99. |
| `mentality_positioning` | Positioning detailed attribute (mentality group), 1-99. |
| `mentality_vision` | Vision detailed attribute (mentality group), 1-99. |
| `mentality_penalties` | Penalties detailed attribute (mentality group), 1-99. |
| `mentality_composure` | Composure detailed attribute (mentality group), 1-99. |
| `defending_awareness` | Awareness detailed attribute (defending group), 1-99. |
| `defending_standing_tackle` | Standing tackle detailed attribute (defending group), 1-99. |
| `defending_sliding_tackle` | Sliding tackle detailed attribute (defending group), 1-99. |
| `goalkeeping_diving` | Diving detailed attribute (goalkeeping group), 1-99. |
| `goalkeeping_handling` | Handling detailed attribute (goalkeeping group), 1-99. |
| `goalkeeping_kicking` | Kicking detailed attribute (goalkeeping group), 1-99. |
| `goalkeeping_positioning` | Positioning detailed attribute (goalkeeping group), 1-99. |
| `goalkeeping_reflexes` | Reflexes detailed attribute (goalkeeping group), 1-99. |
| `edition` | Game edition snapshot came from, e.g. fc27. |
| `snapshot_date` | Date the snapshot was taken. |

</details>

## Rebuilding the Dashboard

Requires PowerShell (built-in on Windows, or `pwsh` on macOS/Linux):

```powershell
cd "EA_FC_PLAYERS_DATASET_AND_ DASHBOARD"
./build.ps1
```

This regenerates `dashboard.html` from `src/dashboard_template.html` plus the files in `data/`. Copy the result over `index.html` at the repo root to update the live demo.

## Tech Stack

Vanilla HTML/CSS/JS with D3.js (map) and Chart.js (charts) — no framework, no server, no dependencies to install. PowerShell scripts handle data extraction and the build pipeline.

## Source & Legal

Data sourced from EA's public ratings API. All player data, trademarks, and club names belong to Electronic Arts Inc. This is an unofficial, non-commercial project built for data analysis, exploration, and education.

## Author

**Lakshmi Kanth** — [github.com/LakshmiKanth11](https://github.com/LakshmiKanth11)
