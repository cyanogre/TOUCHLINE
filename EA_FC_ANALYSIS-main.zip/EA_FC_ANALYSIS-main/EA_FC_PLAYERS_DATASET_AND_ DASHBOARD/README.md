# EA SPORTS FC 27 — World Player Atlas & Dataset

Interactive World Player Atlas and complete player statistics dataset from EA SPORTS FC 27 (19,789 players across 164 countries and 702 clubs).

---

## 📁 Project Directory Structure

```text
EA FC PLAYERS DATA SET/
├── dashboard.html          # Primary Interactive Web Dashboard (Self-contained, open in browser)
├── build.ps1               # Root build runner script (recompiles dashboard.html)
├── README.md               # Project documentation, directory map, and schema definitions
│
├── src/                    # Source templates & frontend code
│   └── dashboard_template.html  # Modular dashboard HTML/CSS/JS template
│
├── data/                   # Raw & processed data files
│   ├── players.csv         # Full EA FC 27 raw player dataset (19,789 rows)
│   ├── country_data.json   # Aggregated national statistics (positions, top players, leagues)
│   ├── players_search.json # Search & comparison index with 6 face + detailed attributes
│   ├── top_clubs_rating.json # Club average ratings, squad sizes, and star players
│   └── world-110m.json     # World TopoJSON geographic data for D3.js map
│
├── scripts/                # Data extraction and build automation scripts
│   ├── build_dashboard.ps1 # Compiles template + JSON data into standalone dashboard.html
│   ├── extract_data.ps1    # Extracts general summary and frequency distributions
│   ├── extract_detailed.ps1 # Builds country_data.json from players.csv
│   ├── extract_players_json.ps1 # Builds players_search.json from players.csv
│   └── extract_clubs_rating.ps1 # Builds top_clubs_rating.json from players.csv
│
└── reports/                # Text report summaries & aggregations
    ├── summary.txt         # Dataset overview (player, country, club, league counts)
    ├── nationality_counts.txt # Player counts ranked by nationality
    ├── position_counts.txt # Distribution of players by position
    ├── league_counts.txt   # Player counts across top leagues
    ├── avg_rating_by_country.txt # Average player ratings by country
    └── gender_by_country.txt # Men vs. Women breakdown by country
```

---

## 🚀 Quick Start: Using the Dashboard

1. **Launch**: Double-click or open [dashboard.html](file:///c:/KAGGLE%20PROJECT%20FILE/EA%20FC%20PLAYERS%20DATA%20SET/dashboard.html) in Google Chrome, Microsoft Edge, or any modern web browser.
2. **Master Filter Ribbon**:
   - Filter by **Position** (Attackers, Midfielders, Defenders, Goalkeepers, or specific roles: ST, LW, RW, CAM, CM, CDM, LM, RM, CB, LB, RB, GK).
   - Filter by **Gender** (Men Only, Women Only, All).
   - Filter by **Continent** (Europe, South America, Africa, Asia, North America, Oceania).
   - Filter by **Rating Tier** (85+ Superstars, 80–84 Top Flight, 70–79 Professional, <70 Emerging).
   - Click `↺ Reset All` to restore the complete database at any time.
3. **Interactive Charts & World Map**:
   - Click any country on the **Global Map** to isolate that nation's players and ratings.
   - Use per-card headers to customize metrics, position sub-filters, or sorting.
   - Click any doughnut slice or bar chart item to filter by position or country.
4. **Head-to-Head Player Comparison**:
   - Click quick battle preset buttons (e.g., `⚡ Mbappé vs Haaland`, `⚡ Putellas vs Bonmatí`).
   - Use the position pills (`ATT`, `MID`, `DEF`, `GK`) to filter search candidates and compare any two players across radar charts and 16 attribute bars.
5. **Rebuilding**:
   - Run `.\build.ps1` from PowerShell to recompile `dashboard.html` whenever template or data files change.

---

## 📊 Dataset Overview

All 19,789 players from EA's official ratings API for EA SPORTS FC 27, snapshot taken 2026-09-12. One row per player.

The file has every stat EA publishes: the six card facets (pace through physicality), the 34 detailed attributes behind them, and the goalkeeping stats for the 2,204 goalkeepers in the set.

`playstyles` lists a player's PlayStyles, comma separated (41% of players have at least one). A PlayStyle+ comes last and keeps EA's own trailing `+`, as in `Finesse Shot+`.

### Men's and Women's Football

Both divisions are in this dataset:
- `gender` column separates them: "Men's Football" (17,849 players) and "Women's Football" (1,940 players).
- Filter in Python/pandas: `df[df.gender == "Women's Football"]`.

---

## 📋 Schema Columns (`data/players.csv`)

| Column | Description |
|---|---|
| `player_id` | EA's numeric player id, stable across snapshots. |
| `common_name` | Single display name EA gives some players. Blank for most. |
| `first_name` | First name. |
| `last_name` | Last name. |
| `overall_rating` | Overall card rating, 1-99. |
| `position` | Primary position, EA's short label (GK, CB, ST, ...). |
| `alternate_positions` | Other playable positions, space separated. Blank if none. |
| `club` | Club the player plays for. |
| `league` | League the club plays in. |
| `nationality` | Country EA lists for the player. |
| `gender` | EA's division label: "Men's Football" or "Women's Football". |
| `preferred_foot` | Right or Left. |
| `skill_moves` | Skill moves star rating, 1-5. |
| `weak_foot` | Weak foot star rating, 1-5. |
| `height_cm` | Height in centimeters (if populated). |
| `weight_kg` | Weight in kilograms (if populated). |
| `birthdate` | Birthdate as an ISO 8601 date (YYYY-MM-DD). |
| `playstyles` | PlayStyles, comma separated. A PlayStyle+ keeps EA's trailing +. |
| `pace` | Pace card facet, 1-99. |
| `shooting` | Shooting card facet, 1-99. |
| `passing` | Passing card facet, 1-99. |
| `dribbling` | Dribbling card facet, 1-99. |
| `defending` | Defending card facet, 1-99. |
| `physicality` | Physicality card facet, 1-99. |
| `attacking_crossing` | Crossing detailed attribute (attacking group), 1-99. |
| `attacking_finishing` | Finishing detailed attribute (attacking group), 1-99. |
| `attacking_heading_accuracy` | Heading accuracy detailed attribute (attacking group), 1-99. |
| `attacking_short_passing` | Short passing detailed attribute (attacking group), 1-99. |
| `attacking_volleys` | Volleys detailed attribute (attacking group), 1-99. |
| `skill_dribbling` | Dribbling detailed attribute (skill group), 1-99. |
| `skill_curve` | Curve detailed attribute (skill group), 1-99. |
| `skill_fk_accuracy` | Free kick accuracy detailed attribute (skill group), 1-99. |
| `skill_long_passing` | Long passing detailed attribute (skill group), 1-99. |
| `skill_ball_control` | Ball control detailed attribute (skill group), 1-99. |
| `movement_acceleration` | Acceleration detailed attribute (movement group), 1-99. |
| `movement_sprint_speed` | Sprint speed detailed attribute (movement group), 1-99. |
| `movement_agility` | Agility detailed attribute (movement group), 1-99. |
| `movement_reactions` | Reactions detailed attribute (movement group), 1-99. |
| `movement_balance` | Balance detailed attribute (movement group), 1-99. |
| `power_shot_power` | Shot power detailed attribute (power group), 1-99. |
| `power_jumping` | Jumping detailed attribute (power group), 1-99. |
| `power_stamina` | Stamina detailed attribute (power group), 1-99. |
| `power_strength` | Strength detailed attribute (power group), 1-99. |
| `power_long_shots` | Long shots detailed attribute (power group), 1-99. |
| `mentality_aggression` | Aggression detailed attribute (mentality group), 1-99. |
| `mentality_interceptions` | Interceptions detailed attribute (mentality group), 1-99. |
| `mentality_positioning` | Positioning detailed attribute (mentality group), 1-99. |
| `mentality_vision` | Vision detailed attribute (mentality group), 1-99. |
| `mentality_penalties` | Penalties detailed attribute (mentality group), 1-99. |
| `mentality_composure` | Composure detailed attribute (mentality group), 1-99. |
| `defending_awareness` | Awareness detailed attribute (defending group), 1-99. |
| `defending_standing_tackle` | Standing tackle detailed attribute (defending group), 1-99. |
| `defending_sliding_tackle` | Sliding tackle detailed attribute (defending group), 1-99. |
| `goalkeeping_diving` | Diving detailed attribute (goalkeeping group), 1-99. |
| `goalkeeping_handling` | Handling detailed attribute (goalkeeping group), 1-99. |
| `goalkeeping_kicking` | Kicking detailed attribute (goalkeeping group), 1-99. |
| `goalkeeping_positioning` | Positioning detailed attribute (goalkeeping group), 1-99. |
| `goalkeeping_reflexes` | Reflexes detailed attribute (goalkeeping group), 1-99. |
| `edition` | Game edition snapshot came from, e.g. fc27. |
| `snapshot_date` | Date the snapshot was taken. |

---

## Source and Legal

The data originates from EA's public ratings API. All player data, trademarks, and club names belong to Electronic Arts Inc. This is an unofficial, non-commercial project for data analysis, exploration, and education.
