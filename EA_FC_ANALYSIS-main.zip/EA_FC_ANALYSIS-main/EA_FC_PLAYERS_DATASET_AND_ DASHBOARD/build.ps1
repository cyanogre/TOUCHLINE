# Root-level build runner
$scriptPath = Join-Path $PSScriptRoot 'scripts\build_dashboard.ps1'
& $scriptPath
