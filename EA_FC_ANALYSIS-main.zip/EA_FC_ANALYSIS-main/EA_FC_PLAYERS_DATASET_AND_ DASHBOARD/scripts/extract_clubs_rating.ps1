# Extract top clubs by average rating (min 5 players)
$scriptDir = $PSScriptRoot
$rootDir = Split-Path -Parent $scriptDir
$dataDir = Join-Path $rootDir 'data'

$csv = Import-Csv (Join-Path $dataDir 'players.csv')
$clubs = @{}
foreach ($p in $csv) {
    $club = $p.club
    $rating = [int]$p.overall_rating
    if ($club -and $club.Trim() -ne '') {
        if (-not $clubs.ContainsKey($club)) {
            $clubs[$club] = @{ sum = 0; count = 0; max = 0; top = '' }
        }
        $clubs[$club].sum += $rating
        $clubs[$club].count++
        if ($rating -gt $clubs[$club].max) {
            $clubs[$club].max = $rating
            $name = if ($p.common_name -and $p.common_name.Trim() -ne '') { $p.common_name } else { ($p.first_name + ' ' + $p.last_name).Trim() }
            $clubs[$club].top = $name
        }
    }
}
$result = $clubs.GetEnumerator() | Where-Object { $_.Value.count -ge 5 } | ForEach-Object {
    [PSCustomObject]@{
        cl   = $_.Key
        avg  = [math]::Round($_.Value.sum / $_.Value.count, 1)
        cnt  = $_.Value.count
        max  = $_.Value.max
        star = $_.Value.top
    }
} | Sort-Object avg -Descending | Select-Object -First 30

$outFile = Join-Path $dataDir 'top_clubs_rating.json'
$result | ConvertTo-Json -Compress | Out-File $outFile -Encoding UTF8
Write-Host "Exported $($result.Count) top clubs by rating to $outFile"
