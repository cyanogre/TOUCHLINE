# Extract player data for fast search and comparison
$scriptDir = $PSScriptRoot
$rootDir = Split-Path -Parent $scriptDir
$dataDir = Join-Path $rootDir 'data'

$csv = Import-Csv (Join-Path $dataDir 'players.csv')

$players = foreach ($p in $csv) {
    $name = if ($p.common_name -and $p.common_name.Trim() -ne '') { $p.common_name } else { "$($p.first_name) $($p.last_name)".Trim() }
    
    [PSCustomObject]@{
        id     = $p.player_id
        name   = $name
        ovr    = [int]$p.overall_rating
        pos    = $p.position
        club   = $p.club
        league = $p.league
        nat    = $p.nationality
        gender = if ($p.gender -like '*Women*') { 'Women' } else { 'Men' }
        foot   = $p.preferred_foot
        sm     = [int]($p.skill_moves)
        wf     = [int]($p.weak_foot)
        
        # 6 Core Face Attributes
        pac    = [int]($p.pace)
        sho    = [int]($p.shooting)
        pas    = [int]($p.passing)
        dri    = [int]($p.dribbling)
        def    = [int]($p.defending)
        phy    = [int]($p.physicality)
        
        # Detailed stats subset
        acc    = [int]($p.movement_acceleration)
        spd    = [int]($p.movement_sprint_speed)
        fin    = [int]($p.attacking_finishing)
        pow    = [int]($p.power_shot_power)
        vis    = [int]($p.mentality_vision)
        shortP = [int]($p.attacking_short_passing)
        longP  = [int]($p.skill_long_passing)
        ctrl   = [int]($p.skill_ball_control)
        agi    = [int]($p.movement_agility)
        rea    = [int]($p.movement_reactions)
        sta    = [int]($p.power_stamina)
        str    = [int]($p.power_strength)
        tck    = [int]($p.defending_standing_tackle)
        posn   = [int]($p.mentality_positioning)

        ps     = $p.playstyles
    }
}

# Sort by OVR desc
$players = $players | Sort-Object ovr -Descending

$outFile = Join-Path $dataDir 'players_search.json'
$players | ConvertTo-Json -Compress | Out-File $outFile -Encoding UTF8
Write-Host "Exported $($players.Count) players to $outFile"
