$scriptDir = $PSScriptRoot
$rootDir = Split-Path -Parent $scriptDir
$dataDir = Join-Path $rootDir 'data'
$reportsDir = Join-Path $rootDir 'reports'

$csv = Import-Csv (Join-Path $dataDir 'players.csv')

# Nationality breakdown
$nationalityData = $csv | Group-Object nationality | Sort-Object Count -Descending | ForEach-Object {
    "$($_.Name)|$($_.Count)"
}
$nationalityData | Out-File (Join-Path $reportsDir 'nationality_counts.txt') -Encoding UTF8

# Position breakdown by nationality (top 20)
$top20 = $csv | Group-Object nationality | Sort-Object Count -Descending | Select-Object -First 30

# Average rating by nationality (top 20)
$ratingData = $top20 | ForEach-Object {
    $country = $_.Name
    $avgRating = ($_.Group | Measure-Object overall_rating -Average).Average
    "$country|$([math]::Round($avgRating, 1))"
}
$ratingData | Out-File (Join-Path $reportsDir 'avg_rating_by_country.txt') -Encoding UTF8

# Gender breakdown by nationality (top 20)  
$genderData = $top20 | ForEach-Object {
    $country = $_.Name
    $men = ($_.Group | Where-Object { $_.gender -eq "Men's Football" } | Measure-Object).Count
    $women = ($_.Group | Where-Object { $_.gender -eq "Women's Football" } | Measure-Object).Count
    "$country|$men|$women"
}
$genderData | Out-File (Join-Path $reportsDir 'gender_by_country.txt') -Encoding UTF8

# Position distribution
$positionData = $csv | Group-Object position | Sort-Object Count -Descending | ForEach-Object {
    "$($_.Name)|$($_.Count)"
}
$positionData | Out-File (Join-Path $reportsDir 'position_counts.txt') -Encoding UTF8

# League breakdown (top 15)
$leagueData = $csv | Group-Object league | Sort-Object Count -Descending | Select-Object -First 15 | ForEach-Object {
    "$($_.Name)|$($_.Count)"
}
$leagueData | Out-File (Join-Path $reportsDir 'league_counts.txt') -Encoding UTF8

# Summary stats
$totalPlayers = $csv.Count
$totalCountries = ($csv | Select-Object nationality -Unique).Count
$totalLeagues = ($csv | Select-Object league -Unique).Count
$totalClubs = ($csv | Select-Object club -Unique).Count
$avgRatingOverall = [math]::Round(($csv | Measure-Object overall_rating -Average).Average, 1)

$summaryFile = Join-Path $reportsDir 'summary.txt'
"Total Players: $totalPlayers" | Out-File $summaryFile -Encoding UTF8
"Total Countries: $totalCountries" | Add-Content $summaryFile -Encoding UTF8
"Total Leagues: $totalLeagues" | Add-Content $summaryFile -Encoding UTF8
"Total Clubs: $totalClubs" | Add-Content $summaryFile -Encoding UTF8
"Average Rating: $avgRatingOverall" | Add-Content $summaryFile -Encoding UTF8

Write-Host "Done extracting data to reports/ folder."
