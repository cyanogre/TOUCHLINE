# Build dashboard script with player comparison data + club ratings
$scriptDir = $PSScriptRoot
$rootDir = Split-Path -Parent $scriptDir
$dataDir = Join-Path $rootDir 'data'
$srcDir = Join-Path $rootDir 'src'

$templatePath = Join-Path $srcDir 'dashboard_template.html'
if (-not (Test-Path $templatePath)) {
    $templatePath = Join-Path $rootDir 'dashboard_template.html'
}

$template = Get-Content $templatePath -Raw -Encoding UTF8
$countryData = Get-Content (Join-Path $dataDir 'country_data.json') -Raw -Encoding UTF8
$worldData = Get-Content (Join-Path $dataDir 'world-110m.json') -Raw -Encoding UTF8
$playersData = Get-Content (Join-Path $dataDir 'players_search.json') -Raw -Encoding UTF8
$clubsRating = Get-Content (Join-Path $dataDir 'top_clubs_rating.json') -Raw -Encoding UTF8

$result = $template.Replace('COUNTRY_DATA_PLACEHOLDER', $countryData)
$result = $result.Replace('WORLD_DATA_PLACEHOLDER', $worldData)
$result = $result.Replace('PLAYERS_DATA_PLACEHOLDER', $playersData)
$result = $result.Replace('CLUBS_RATING_PLACEHOLDER', $clubsRating)

$outPath = Join-Path $rootDir 'dashboard.html'
$utf8NoBom = New-Object System.Text.UTF8Encoding $false
[System.IO.File]::WriteAllText($outPath, $result, $utf8NoBom)

Write-Host "Dashboard built successfully at: $outPath"
