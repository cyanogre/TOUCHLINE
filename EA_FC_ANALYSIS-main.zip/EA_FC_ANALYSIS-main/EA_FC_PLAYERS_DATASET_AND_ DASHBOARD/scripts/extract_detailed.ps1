# Extract detailed country data for atlas
$scriptDir = $PSScriptRoot
$rootDir = Split-Path -Parent $scriptDir
$dataDir = Join-Path $rootDir 'data'

$csv = Import-Csv (Join-Path $dataDir 'players.csv')

# Build JSON-like data for each country: positions, top players, leagues
$groups = $csv | Group-Object nationality | Sort-Object Count -Descending

$lines = @()
$lines += "["

$first = $true
foreach ($g in $groups) {
    $country = $g.Name
    $players = $g.Group
    $count = $g.Count

    # Avg rating
    $avgRating = [math]::Round(($players | Measure-Object overall_rating -Average).Average, 1)

    # Gender
    $men = ($players | Where-Object { $_.gender -eq "Men's Football" } | Measure-Object).Count
    $women = ($players | Where-Object { $_.gender -eq "Women's Football" } | Measure-Object).Count

    # Positions
    $posCounts = $players | Group-Object position | Sort-Object Count -Descending | ForEach-Object {
        '"' + $_.Name + '":' + $_.Count
    }
    $posJson = "{" + ($posCounts -join ",") + "}"

    # Top 5 players by rating
    $topPlayers = $players | Sort-Object { [int]$_.overall_rating } -Descending | Select-Object -First 5
    $topJson = @()
    foreach ($p in $topPlayers) {
        $name = if ($p.common_name) { $p.common_name } else { "$($p.first_name) $($p.last_name)" }
        $name = $name -replace '"', '\"'
        $topJson += '{"n":"' + $name + '","r":' + $p.overall_rating + ',"p":"' + $p.position + '"}'
    }
    $topPlayersStr = "[" + ($topJson -join ",") + "]"

    # Top 3 leagues
    $leagueCounts = $players | Group-Object league | Sort-Object Count -Descending | Select-Object -First 3
    $leagueJson = @()
    foreach ($l in $leagueCounts) {
        $ln = $l.Name -replace '"', '\"'
        $leagueJson += '{"l":"' + $ln + '","c":' + $l.Count + '}'
    }
    $leaguesStr = "[" + ($leagueJson -join ",") + "]"

    # Top 3 clubs
    $clubCounts = $players | Group-Object club | Sort-Object Count -Descending | Select-Object -First 3
    $clubJson = @()
    foreach ($c2 in $clubCounts) {
        $cn = $c2.Name -replace '"', '\"'
        $clubJson += '{"cl":"' + $cn + '","c":' + $c2.Count + '}'
    }
    $clubsStr = "[" + ($clubJson -join ",") + "]"

    $countryEsc = $country -replace '"', '\"'

    $comma = if ($first) { "" } else { "," }
    $first = $false

    $lines += "$comma{`"country`":`"$countryEsc`",`"count`":$count,`"avg`":$avgRating,`"men`":$men,`"women`":$women,`"pos`":$posJson,`"top`":$topPlayersStr,`"leagues`":$leaguesStr,`"clubs`":$clubsStr}"
}

$lines += "]"

$outFile = Join-Path $dataDir 'country_data.json'
$lines -join "`n" | Out-File $outFile -Encoding UTF8
Write-Host "Detailed country data written to $outFile"
