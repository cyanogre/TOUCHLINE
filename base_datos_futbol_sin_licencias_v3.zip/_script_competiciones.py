"""Genera competiciones.json + COMPETICIONES.md y enriquece leagues.json.
Uso: python3 -I competitions.py out
"""
import json, sys, collections as C

OUT = sys.argv[1]
leagues = json.load(open(f'{OUT}/leagues.json', encoding='utf-8'))
clubs = {c['id']: c for c in json.load(open(f'{OUT}/clubs.json', encoding='utf-8'))}

# ------------------------------------------------------------------ asociaciones
# país (league_country) -> (código, confederación, ranking UEFA 2026-27 o None, región AFC)
ASSOC = {
 'Inglaterra': ('ENG', 'UEFA', 1), 'Italia': ('ITA', 'UEFA', 2), 'España': ('ESP', 'UEFA', 3), 'Alemania': ('GER', 'UEFA', 4),
 'Francia': ('FRA', 'UEFA', 5), 'Países Bajos': ('NED', 'UEFA', 6), 'Portugal': ('POR', 'UEFA', 7), 'Bélgica': ('BEL', 'UEFA', 8),
 'Chequia': ('CZE', 'UEFA', 9), 'Turquía': ('TUR', 'UEFA', 10), 'Noruega': ('NOR', 'UEFA', 11), 'Grecia': ('GRE', 'UEFA', 12),
 'Austria': ('AUT', 'UEFA', 13), 'Escocia': ('SCO', 'UEFA', 14), 'Polonia': ('POL', 'UEFA', 15), 'Dinamarca': ('DEN', 'UEFA', 16),
 'Suiza': ('SUI', 'UEFA', 17), 'Chipre': ('CYP', 'UEFA', 19), 'Suecia': ('SWE', 'UEFA', 20), 'Croacia': ('CRO', 'UEFA', 21),
 'Serbia': ('SRB', 'UEFA', 22), 'Ucrania': ('UKR', 'UEFA', 23), 'Hungría': ('HUN', 'UEFA', 24), 'Rumanía': ('ROU', 'UEFA', 25),
 'Rusia': ('RUS', 'UEFA', 26), 'Bulgaria': ('BUL', 'UEFA', 29), 'Azerbaiyán': ('AZE', 'UEFA', 30), 'Irlanda': ('IRL', 'UEFA', 31),
 'Islandia': ('ISL', 'UEFA', 33), 'Finlandia': ('FIN', 'UEFA', 38),
 'Argentina': ('ARG', 'CONMEBOL', None), 'Brasil': ('BRA', 'CONMEBOL', None), 'Chile': ('CHI', 'CONMEBOL', None),
 'Colombia': ('COL', 'CONMEBOL', None), 'Ecuador': ('ECU', 'CONMEBOL', None), 'Paraguay': ('PAR', 'CONMEBOL', None),
 'Perú': ('PER', 'CONMEBOL', None), 'Bolivia': ('BOL', 'CONMEBOL', None), 'Uruguay': ('URU', 'CONMEBOL', None),
 'Venezuela': ('VEN', 'CONMEBOL', None),
 'Arabia Saudí': ('KSA', 'AFC', None), 'Emiratos Árabes Unidos': ('UAE', 'AFC', None), 'Catar': ('QAT', 'AFC', None),
 'Japón': ('JPN', 'AFC', None), 'Corea del Sur': ('KOR', 'AFC', None), 'China': ('CHN', 'AFC', None),
 'Australia': ('AUS', 'AFC', None), 'Tailandia': ('THA', 'AFC', None), 'India': ('IND', 'AFC', None),
 'Estados Unidos': ('USA', 'CONCACAF', None), 'México': ('MEX', 'CONCACAF', None),
 'Egipto': ('EGY', 'CAF', None), 'Marruecos': ('MAR', 'CAF', None),
}
AFC_REGION = {'KSA': 'Oeste', 'UAE': 'Oeste', 'QAT': 'Oeste', 'JPN': 'Este', 'KOR': 'Este', 'CHN': 'Este', 'AUS': 'Este', 'THA': 'Este', 'IND': 'Sur'}
EXCLUDED = {'RUS': 'Excluida de las competiciones UEFA (como en la realidad). Configurable: excluir_rusia=true.'}
# puntos iniciales aproximados del coeficiente de asociación UEFA (5 temporadas) — solo para ordenar la temporada 1
UEFA_INIT_POINTS = {1: 115, 2: 96, 3: 92, 4: 88, 5: 76, 6: 68, 7: 64, 8: 58, 9: 52, 10: 47, 11: 45, 12: 43, 13: 38, 14: 37, 15: 36,
                    16: 35, 17: 34, 19: 31, 20: 30, 21: 29, 22: 28, 23: 27, 24: 26, 25: 25, 26: 24, 29: 21, 30: 20, 31: 19, 33: 17, 38: 13}

def division(name):
    if 'Femenina' in name: return None
    for n in (' 2', ' 3', ' 4'):
        if name.endswith(n): return int(n.strip())
    return 1

by_country = C.defaultdict(list)
for l in leagues:
    code, conf, rank = ASSOC.get(l['country'], (None, None, None))
    l['asociacion'], l['confederacion'] = code, conf
    l['division'] = division(l['name'])
    l['ranking_uefa'] = rank
    if code in AFC_REGION: l['region_afc'] = AFC_REGION[code]
    by_country[code].append(l)
for c in clubs.values():
    c['coef_inicial'] = round(max(0.0, c['avg_xi'] - 60) * 4, 1)
json.dump(list(clubs.values()), open(f'{OUT}/clubs.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=0)
json.dump(leagues, open(f'{OUT}/leagues.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)

top_league = {}
for code, ls in by_country.items():
    if code is None: continue
    t = [l for l in ls if l['division'] == 1]
    if t: top_league[code] = t[0]

def n_clubs(code): return len(top_league[code]['club_ids']) if code in top_league else 0

# ------------------------------------------------------------------ UEFA: listas de acceso por defecto (2024-27)
# tipo de plaza: C=campeón, RU=2º, P3..P6 = puesto, CW = campeón de copa (sin copa -> mejor clasificado no clasificado), EPS = plaza por rendimiento
UEFA = {
 'campions': {
  'fase_liga_directos': [('TH', 'campions'), ('TH', 'euroleague'), ('C', 1, 10), ('RU', 1, 6), ('P3', 1, 5), ('P4', 1, 4), ('EPS', 2)],
  'caminos': {
   'campeones': [('Q1', 14, [('C', 25, 55)]), ('Q2', 12, [('C', 15, 24)]), ('Q3', 6, []), ('PO', 5, [('C', 11, 14)])],
   'liga':      [('Q2', 3, [('RU', 10, 15)]), ('Q3', 4, [('RU', 7, 9), ('P3', 6, 6), ('P4', 5, 5)]), ('PO', 2, [])],
  },
 },
 'euroleague': {
  'fase_liga_directos': [('TH', 'rising'), ('CW', 1, 7), ('P5', 1, 5)],
  'PO': (12, [('CW', 8, 12)]),
  'caminos': {
   'campeones': [('Q3', 6, [])],
   'principal': [('Q1', 6, [('CW', 21, 33)]), ('Q2', 9, [('CW', 16, 20), ('P3', 7, 12), ('P4', 6, 6)]), ('Q3', 7, [('CW', 13, 15)])],
  },
 },
 'rising': {
  'caminos': {
   'campeones': [('Q2', 6, []), ('Q3', 4, []), ('PO', 5, [])],
   'principal': [('Q1', 26, [('CW', 45, 55), ('RU', 34, 55), ('P3', 30, 50)]),
                 ('Q2', 43, [('CW', 34, 44), ('RU', 16, 33), ('P3', 13, 29), ('P4', 7, 15), ('P5', 6, 6)]),
                 ('Q3', 26, []), ('PO', 19, [('P6', 1, 5)])],
  },
 },
}
# flujos de eliminados (perdedores) entre competiciones: (comp, camino, ronda) -> (comp, camino, ronda | 'LIGA')
TRANSFERS = [
 (('campions', 'campeones', 'Q1'), ('rising', 'campeones', 'Q2')),
 (('campions', 'campeones', 'Q2'), ('euroleague', 'campeones', 'Q3')),
 (('campions', 'liga', 'Q2'), ('euroleague', 'principal', 'Q3')),
 (('campions', 'campeones', 'Q3'), ('euroleague', None, 'PO')),
 (('campions', 'liga', 'Q3'), ('euroleague', None, 'LIGA')),
 (('campions', 'campeones', 'PO'), ('euroleague', None, 'LIGA')),
 (('campions', 'liga', 'PO'), ('euroleague', None, 'LIGA')),
 (('euroleague', 'principal', 'Q1'), ('rising', 'principal', 'Q2')),
 (('euroleague', 'principal', 'Q2'), ('rising', 'principal', 'Q3')),
 (('euroleague', 'campeones', 'Q3'), ('rising', 'campeones', 'PO')),
 (('euroleague', 'principal', 'Q3'), ('rising', 'principal', 'PO')),
 (('euroleague', None, 'PO'), ('rising', None, 'LIGA')),
]
ROUND_ORDER = {'LIGA': 5, 'PO': 4, 'Q3': 3, 'Q2': 2, 'Q1': 1, 'PR': 0}

uefa_assocs = sorted([(rk, code) for country, (code, conf, rk) in ASSOC.items()
                      if conf == 'UEFA' and code in top_league and code not in EXCLUDED], key=lambda t: t[0])
RANK2CODE = {rk: code for rk, code in uefa_assocs}
EPS_ASSOCS = [uefa_assocs[0][1], uefa_assocs[1][1]]  # temporada 1: las 2 primeras del ranking

def slot_list(spec):
    """Expande la especificación a [(tipo, rank)] solo para asociaciones presentes."""
    out = []
    for s in spec:
        if s[0] in ('TH', 'EPS'): continue
        typ, a, b = s
        for rk in range(a, b + 1):
            if rk in RANK2CODE: out.append((typ, rk))
    return out

# 1) reparto de puestos de liga por asociación (en orden de prestigio de la plaza)
assoc_slots = C.defaultdict(list)  # code -> [(comp, path, round, typ)]
def add(comp, path, rnd, spec):
    for typ, rk in slot_list(spec):
        assoc_slots[RANK2CODE[rk]].append((comp, path, rnd, typ))
add('campions', None, 'LIGA', UEFA['campions']['fase_liga_directos'])
for code in EPS_ASSOCS: assoc_slots[code].append(('campions', None, 'LIGA', 'EPS'))
for path, rounds in UEFA['campions']['caminos'].items():
    for rnd, _, spec in rounds: add('campions', path, rnd, spec)
add('euroleague', None, 'LIGA', UEFA['euroleague']['fase_liga_directos'])
add('euroleague', None, 'PO', UEFA['euroleague']['PO'][1])
for path, rounds in UEFA['euroleague']['caminos'].items():
    for rnd, _, spec in rounds: add('euroleague', path, rnd, spec)
for path, rounds in UEFA['rising']['caminos'].items():
    for rnd, _, spec in rounds: add('rising', path, rnd, spec)

COMP_ORDER = {'campions': 0, 'euroleague': 1, 'rising': 2}
TYP_ORDER = {'C': 0, 'RU': 1, 'P3': 2, 'P4': 3, 'EPS': 4, 'P5': 5, 'CW': 5, 'P6': 6}
assign = {}  # code -> list of (position, comp, path, round, typ)
entrants = C.defaultdict(list)  # (comp, path, round) -> [entrant dict]
for code, sl in assoc_slots.items():
    sl.sort(key=lambda t: (COMP_ORDER[t[0]], -ROUND_ORDER[t[2]], TYP_ORDER[t[3]]))
    pos, rows = 1, []
    for comp, path, rnd, typ in sl:
        if pos > n_clubs(code): break  # liga parcial: no hay más clubes
        rows.append((pos, comp, path, rnd, typ))
        rk = [r for r, c in uefa_assocs if c == code][0]
        entrants[(comp, path, rnd)].append({'asoc': code, 'rank': rk, 'puesto': pos, 'plaza': typ})
        pos += 1
    assign[code] = rows

# 2) algoritmo de reequilibrio (top-down, eliminatorias con tope de diseño, exentos = los más fuertes)
def strength(e):  # mayor = más fuerte (temporada 1: ronda de entrada, ranking asociación, puesto)
    return (ROUND_ORDER[e['ronda']], -e['rank'], -e['puesto'])

def solve_path(rounds, target):
    """rounds: [(nombre, eliminatorias_diseño, [entrants])] de primera a última. Devuelve detalle por ronda."""
    for name, _, ents in rounds:
        for e in ents: e['ronda'] = name
    res = {name: {'eliminatorias': 0, 'participantes': [], 'exentos_a_siguiente': []} for name, _, _ in rounds}
    qualified = []
    allents = [e for _, _, ents in rounds for e in ents]
    if len(allents) <= target:
        return res, allents, target - len(allents)
    need = target
    pool_below = list(allents)
    for i in range(len(rounds) - 1, -1, -1):
        name, design, ents = rounds[i]
        here = [e for e in pool_below if e['ronda'] == name]
        below = [e for e in pool_below if ROUND_ORDER[e['ronda']] < ROUND_ORDER[name]]
        Ni = len(here) + len(below)
        if Ni <= need:
            res[name]['exentos_a_siguiente'] = here + below
            if i == len(rounds) - 1: qualified += here + below
            need = 0; pool_below = []
            break
        t = (Ni - need) if i == 0 else min(design, Ni - need)
        t = min(t, Ni // 2)
        cand = sorted(here + below, key=strength, reverse=True)
        byes = cand[:need - t]
        rest = cand[need - t:]
        if i == len(rounds) - 1: qualified += byes
        res[name]['exentos_a_siguiente'] = byes
        here_rem = [e for e in rest if e in here]
        below_rem = [e for e in rest if e not in here]
        if len(here_rem) > 2 * t:  # sobran directos: los más débiles bajan de ronda
            here_rem.sort(key=strength, reverse=True)
            for e in here_rem[2 * t:]: e['ronda'] = rounds[i - 1][0] if i > 0 else name
            below_rem += here_rem[2 * t:]; here_rem = here_rem[:2 * t]
        res[name]['eliminatorias'] = t
        res[name]['participantes'] = here_rem
        need = 2 * t - len(here_rem)
        pool_below = below_rem
        if i == 0 and pool_below:
            raise ValueError('quedan equipos sin ubicar')
    return res, qualified, 0

def mk(comp, path, rnd): return entrants.get((comp, path, rnd), [])
season1 = {}
# ---- campions
direct = mk('campions', None, 'LIGA')
vac_th = 2  # temporada 1 sin campeones vigentes
lp_target = 2 + 1   # vacante del campeón de euroleague -> camino de liga (regla UEFA)
cp_target = 36 - len(direct) - lp_target
paths = {}
for path, rounds in UEFA['campions']['caminos'].items():
    rr = [(r, d, [dict(e) for e in mk('campions', path, r)]) for r, d, _ in rounds]
    paths[path] = solve_path(rr, cp_target if path == 'campeones' else lp_target)
season1['campions'] = {'directos_fase_liga': len(direct), 'caminos': paths, 'objetivos': {'campeones': cp_target, 'liga': lp_target}}

def losers(comp, path, rnd):
    p = season1[comp]['caminos'][path][0] if path else season1[comp]['po'][0]
    return p[rnd]['eliminatorias'] if path else p['eliminatorias']

# ---- euroleague
tr = C.Counter()
for (src, dst) in TRANSFERS:
    if src[0] == 'campions':
        tr[dst] += season1['campions']['caminos'][src[1]][0][src[2]]['eliminatorias']
el_direct = len(mk('euroleague', None, 'LIGA')) + tr[('euroleague', None, 'LIGA')]
el_po_target = 36 - el_direct
po_direct = len(mk('euroleague', None, 'PO')) + tr[('euroleague', None, 'PO')]
# PO: el_po_target eliminatorias (diseño 12, +1 por vacante campeón Rising en temporada 1 -> ya incluido en 36-directos)
el_po_ties = el_po_target
need_below = 2 * el_po_ties - po_direct
cp_in = tr[('euroleague', 'campeones', 'Q3')]
cp_t = min(cp_in // 2, need_below)
cp_q = cp_in - cp_t if cp_in - cp_t <= need_below else None
cp_winners = max(0, min(cp_in - cp_t, need_below))
mp_target = need_below - cp_winners
mp_rounds = []
for r, d, spec in UEFA['euroleague']['caminos']['principal']:
    ents = [dict(e) for e in mk('euroleague', 'principal', r)]
    ents += [{'asoc': 'TRANSF', 'rank': 99, 'puesto': 99, 'plaza': 'perdedor campions'}] * 0
    mp_rounds.append((r, d, ents))
# añadir transferidos de campions a Q3 principal como entrantes genéricos
for _ in range(tr[('euroleague', 'principal', 'Q3')]):
    mp_rounds[2][2].append({'asoc': 'CAMPIONS', 'rank': 10, 'puesto': 0, 'plaza': 'eliminado Q2 camino liga Campions'})
mp = solve_path(mp_rounds, mp_target)
season1['euroleague'] = {'directos_fase_liga': el_direct, 'po': ({'eliminatorias': el_po_ties}, None, 0),
                         'po_detalle': {'eliminatorias': el_po_ties, 'directos': po_direct, 'desde_camino_campeones': cp_winners,
                                        'desde_camino_principal': mp_target},
                         'caminos': {'campeones': ({'Q3': {'eliminatorias': cp_t, 'participantes': [], 'exentos_a_siguiente': [None] * cp_winners}}, None, 0),
                                     'principal': mp}}
# ---- rising
tr2 = C.Counter()
for (src, dst) in TRANSFERS:
    if src[0] == 'euroleague':
        if src[1] is None: n = el_po_ties
        elif src[1] == 'campeones': n = cp_t
        else: n = mp[0][src[2]]['eliminatorias']
        tr2[dst] += n
    elif src[0] == 'campions' and dst[0] == 'rising':
        tr2[dst] += season1['campions']['caminos'][src[1]][0][src[2]]['eliminatorias']
rl_direct = tr2[('rising', None, 'LIGA')]
rl_need = 36 - rl_direct
cp_rounds = [('Q2', 6, [{'asoc': 'CAMPIONS', 'rank': 30, 'puesto': 0, 'plaza': 'eliminado Q1 Campions'} for _ in range(tr2[('rising', 'campeones', 'Q2')])]),
             ('Q3', 4, []), ('PO', 5, [{'asoc': 'EUROLEAGUE', 'rank': 20, 'puesto': 0, 'plaza': 'eliminado Q3 camino campeones Euroleague'} for _ in range(tr2[('rising', 'campeones', 'PO')])])]
n_cp = sum(len(x[2]) for x in cp_rounds)
rcp_target = min(5, max(0, n_cp // 2)) if n_cp else 0
rcp = solve_path(cp_rounds, rcp_target) if n_cp else ({}, [], rcp_target)
rmp_target = rl_need - rcp_target
mp_r = []
for r, d, spec in UEFA['rising']['caminos']['principal']:
    ents = [dict(e) for e in mk('rising', 'principal', r)]
    extra = tr2[('rising', 'principal', r)]
    ents += [{'asoc': 'EUROLEAGUE', 'rank': 25, 'puesto': 0, 'plaza': f'eliminado {r if r != "PO" else "Q3"} Euroleague'} for _ in range(extra)]
    mp_r.append((r, d, ents))
rmp = solve_path(mp_r, rmp_target)
season1['rising'] = {'directos_fase_liga': rl_direct, 'objetivos': {'campeones': rcp_target, 'principal': rmp_target},
                     'caminos': {'campeones': rcp, 'principal': rmp}}

def check(comp):
    s = season1[comp]
    tot = s['directos_fase_liga']
    for path, (res, q, vac) in s['caminos'].items():
        tot += s.get('objetivos', {}).get(path, 0) if comp != 'euroleague' else 0
    if comp == 'euroleague': tot += el_po_ties
    return tot
for comp in ('campions', 'euroleague', 'rising'):
    print(comp, 'fase de liga =', check(comp))

# ------------------------------------------------------------------ tabla temporada 1 por asociación
NAMES = {'campions': 'Campions', 'euroleague': 'Euroleague', 'rising': 'Rising League'}
RN = {'LIGA': 'Fase de liga', 'PO': 'Play-off', 'Q3': '3ª previa', 'Q2': '2ª previa', 'Q1': '1ª previa'}
PN = {None: '', 'campeones': ' (camino campeones)', 'liga': ' (camino liga)', 'principal': ' (camino principal)'}
uefa_table = []
for rk, code in uefa_assocs:
    rows = assign.get(code, [])
    uefa_table.append({'asociacion': code, 'ranking': rk, 'liga': top_league[code]['name'], 'clubes_en_liga': n_clubs(code),
                       'plazas': [{'puesto_liga': p, 'competicion': NAMES[c], 'entrada': RN[r] + PN[pa], 'tipo_plaza': t} for p, c, pa, r, t in rows]})

def round_summary(comp):
    out = []
    s = season1[comp]
    for path, (res, q, vac) in s['caminos'].items():
        for rnd, d in res.items():
            out.append({'camino': path, 'ronda': rnd, 'eliminatorias': d['eliminatorias'],
                        'exentos_que_suben': len(d['exentos_a_siguiente'])})
    return out

# ------------------------------------------------------------------ CONMEBOL
CONMEBOL = {
 'BRA': {'grupos': 5, 'fase2': 2, 'fase1': 0, 'latino': 6, 'latino_entrada': 'Fase de grupos'},
 'ARG': {'grupos': 5, 'fase2': 1, 'fase1': 0, 'latino': 6, 'latino_entrada': 'Fase de grupos'},
 'CHI': {'grupos': 2, 'fase2': 2, 'fase1': 0, 'latino': 4, 'latino_entrada': 'Primera fase (cruce nacional)'},
 'COL': {'grupos': 2, 'fase2': 2, 'fase1': 0, 'latino': 4, 'latino_entrada': 'Primera fase (cruce nacional)'},
}
for c in ('BOL', 'ECU', 'PAR', 'PER', 'URU', 'VEN'):
    CONMEBOL[c] = {'grupos': 2, 'fase2': 1, 'fase1': 1, 'latino': 4, 'latino_entrada': 'Primera fase (cruce nacional)'}
conmebol_table = []
for code, s in CONMEBOL.items():
    p, rows = 1, []
    for k, n, ent in (('Liberadores', s['grupos'], 'Fase de grupos'), ('Liberadores', s['fase2'], 'Fase 2'),
                      ('Liberadores', s['fase1'], 'Fase 1'), ('Latinoamericana', s['latino'], s['latino_entrada'])):
        for _ in range(n):
            rows.append({'puesto_liga': p, 'competicion': k, 'entrada': ent}); p += 1
    conmebol_table.append({'asociacion': code, 'liga': top_league[code]['name'], 'clubes_en_liga': n_clubs(code), 'plazas': rows})
lib_counts = {'grupos_directos': 2 + sum(s['grupos'] for s in CONMEBOL.values()), 'fase2': sum(s['fase2'] for s in CONMEBOL.values()),
              'fase1': sum(s['fase1'] for s in CONMEBOL.values())}
assert lib_counts == {'grupos_directos': 28, 'fase2': 13, 'fase1': 6}, lib_counts
assert sum(s['latino'] for s in CONMEBOL.values()) == 44

# ------------------------------------------------------------------ AFC (Asia Élite) temporada 1 reequilibrada
AFC_REAL = {'Oeste': [('KSA', 4, 1), ('UAE', 3, 1), ('QAT', 3, 0), ('IRN', 2, 0), ('UZB', 1, 1), ('IRQ', 1, 0), ('JOR', 0, 1)],
            'Este': [('JPN', 4, 1), ('KOR', 3, 1), ('THA', 3, 0), ('CHN', 2, 0), ('AUS', 1, 1), ('MAS', 1, 0), ('VIE', 0, 1)]}
afc_table = {}
for region, lst in AFC_REAL.items():
    present = [c for c, _, _ in lst if c in top_league]
    alloc = {c: [0, 0] for c in present}
    vac_d = vac_p = 0
    for c, d, p in lst:
        if c in alloc:
            cap = n_clubs(c)
            dd = min(d, cap); alloc[c][0] = dd; vac_d += d - dd
            pp = min(p, cap - dd); alloc[c][1] = pp; vac_p += p - pp
        else:
            vac_d += d; vac_p += p
    i = 0
    order = [c for c in present if n_clubs(c) > 3]
    while vac_d:
        c = order[i % len(order)]; alloc[c][0] += 1; vac_d -= 1; i += 1
    order_p = [c for c in present if n_clubs(c) > 3][::-1]
    i = 0
    while vac_p:
        c = order_p[i % len(order_p)]; alloc[c][1] += 1; vac_p -= 1; i += 1
    assert sum(a[0] for a in alloc.values()) == 14 and sum(a[1] for a in alloc.values()) == 4, (region, alloc)
    afc_table[region] = [{'asociacion': c, 'liga': top_league[c]['name'], 'directos_fase_liga': a[0], 'play_off': a[1],
                          'puestos_directos': (f'1-{a[0]}' if a[0] > 1 else '1') if a[0] else '-',
                          'puestos_play_off': (f'{a[0]+1}-{a[0]+a[1]}' if a[1] > 1 else str(a[0] + 1)) if a[1] else '-'}
                         for c, a in alloc.items()]

# ------------------------------------------------------------------ especificación
GEN = {
 'eliminatoria_ida_vuelta_uefa': 'Sin valor doble de goles fuera. Empate global -> prórroga 2x15 -> penaltis.',
 'eliminatoria_ida_vuelta_conmebol': 'Sin valor doble de goles fuera. Empate global -> penaltis directamente (sin prórroga).',
 'partido_unico': 'Empate -> prórroga 2x15 -> penaltis (salvo que se indique lo contrario).',
 'desempate_fase_liga_uefa': ['puntos', 'diferencia de goles', 'goles a favor', 'goles a favor fuera', 'victorias', 'victorias fuera',
                               'puntos de los rivales', 'diferencia de goles de los rivales', 'goles a favor de los rivales',
                               'puntos disciplinarios (menos es mejor)', 'coeficiente de club'],
 'desempate_grupos_conmebol': ['puntos', 'diferencia de goles', 'goles a favor', 'goles a favor fuera', 'sorteo'],
 'sin_copa_nacional': 'El juego no tiene copas nacionales: toda plaza de "campeón de copa" pasa al mejor clasificado de liga que aún no tenga plaza (regla real cuando el campeón de copa ya está clasificado).',
 'plaza_ya_ocupada': 'Si un club ya está clasificado para una competición superior (o como campeón vigente), su plaza pasa al siguiente clasificado de su liga no clasificado.',
 'ligas_parciales': 'BUL, AZE y FIN solo tienen 1 club en el juego: ese club es su campeón; el resto de plazas de esas asociaciones quedan vacantes.',
 'vacantes': 'Las plazas de asociaciones que no existen en el juego quedan vacantes y se cubren con el algoritmo de reequilibrio.',
}

REBAL = {
 'descripcion': 'Reequilibrio de rondas previas (adaptación del reequilibrio real UEFA/AFC a las asociaciones que existen en el juego).',
 'pseudocodigo': [
  'Entrada: rondas de un camino (de la primera a la última) con sus entrantes directos y su nº de eliminatorias de diseño; T = nº de clasificados que debe dar el camino.',
  'N = total de entrantes del camino. Si N <= T: todos pasan y quedan T-N vacantes (se cubren con "mejor eliminado" de la última ronda del camino, por coeficiente).',
  'need = T. Para cada ronda i desde la ÚLTIMA hacia la PRIMERA:',
  '  Ni = entrantes de la ronda i + entrantes de todas las rondas anteriores aún sin ubicar.',
  '  t = min(eliminatorias_diseño_i, Ni - need)   (en la primera ronda: t = Ni - need)',
  '  Los (need - t) equipos MÁS FUERTES de ese conjunto quedan exentos de la ronda i y pasan directamente a la siguiente fase.',
  '  La ronda i se juega con 2t equipos: primero los entrantes directos de la ronda i; el resto (2t - directos) vienen como ganadores/exentos de rondas anteriores.',
  '  Si los entrantes directos de la ronda i superan 2t, los más débiles bajan a la ronda anterior.',
  '  need = 2t - directos_ronda_i; continuar con la ronda anterior.',
  'Fortaleza (orden): 1) ronda de entrada más tardía, 2) coeficiente de club, 3) ranking de la asociación, 4) puesto en liga.',
  'Vacante de campeón vigente: como en la UEFA real, se cubre subiendo de ronda al equipo más fuerte del camino correspondiente (campeón vigente de Campions -> camino de campeones; de Euroleague -> camino de liga; de Rising -> play-off de Euroleague).',
 ],
}

def uefa_comp(cid, name, matches, pots, extra):
    return {
     'id': cid, 'nombre': name, 'confederacion': 'UEFA', 'temporada': 'julio-junio',
     'fase_liga': {'equipos': 36, 'partidos_por_equipo': matches,
                   'sorteo': pots, 'restricciones': ['sin rivales de la misma asociación', 'máximo 2 rivales de una misma asociación'],
                   'clasificacion': {'1-8': 'octavos de final (cabezas de serie)', '9-24': 'play-off de eliminatorias (9-16 cabezas de serie, 17-24 no)', '25-36': 'eliminados (no bajan a otra competición)'}},
     'play_off_eliminatorias': {'formato': 'ida y vuelta, vuelta en casa del mejor clasificado',
                                'cruces': ['9/10 vs 23/24', '11/12 vs 21/22', '13/14 vs 19/20', '15/16 vs 17/18'],
                                'nota': 'dentro de cada pareja de puestos se sortea el rival'},
     'octavos': {'formato': 'ida y vuelta, vuelta en casa del mejor clasificado en fase liga',
                 'cruces': ['1/2 vs ganador (15/16 vs 17/18)', '3/4 vs ganador (13/14 vs 19/20)', '5/6 vs ganador (11/12 vs 21/22)', '7/8 vs ganador (9/10 vs 23/24)']},
     'cuadro': 'Fijo desde octavos hasta la final. 1º y 2º en mitades opuestas; 3º y 4º también, etc. (cuadro tipo tenis por puesto en fase liga).',
     'cuartos_y_semis': 'ida y vuelta; vuelta en casa del mejor clasificado en fase liga',
     'final': 'partido único en sede neutral designada antes de la temporada',
     **extra}

COMPS = [
 uefa_comp('campions', 'Campions', 8, '4 bombos de 9 por coeficiente de club (bombo 1: campeón vigente + 8 mejores coeficientes). Cada equipo juega contra 2 rivales de cada bombo: 1 en casa y 1 fuera (4 local, 4 visitante).',
           {'previas': {'caminos': ['campeones', 'liga'], 'formato': 'ida y vuelta; cabezas de serie por coeficiente; sin cruces entre clubes de la misma asociación',
                        'diseño_real': {'campeones': 'Q1 28 equipos -> Q2 24 -> Q3 12 -> Play-off 10 -> 5 a fase liga', 'liga': 'Q2 6 -> Q3 8 -> Play-off 4 -> 2 a fase liga'},
                        'eliminados_van_a': {'Q1 (campeones)': 'Rising League, Q2 camino campeones', 'Q2 campeones': 'Euroleague, Q3 camino campeones',
                                             'Q2 liga': 'Euroleague, Q3 camino principal', 'Q3 campeones': 'Euroleague, play-off',
                                             'Q3 liga': 'Euroleague, fase de liga', 'Play-off (ambos caminos)': 'Euroleague, fase de liga'}},
            'acceso_directo_fase_liga': '29 plazas: campeón vigente Campions, campeón vigente Euroleague, campeones asoc. 1-10, segundos 1-6, terceros 1-5, cuartos 1-4, 2 plazas por rendimiento (5º de las 2 asociaciones con mejor coeficiente de la temporada anterior).',
            'clasifica_a': 'Eurosupercopa (campeón) y fase de liga de Campions de la temporada siguiente'}),
 uefa_comp('euroleague', 'Euroleague', 8, '4 bombos de 9 por coeficiente de club. 2 rivales por bombo (1 casa, 1 fuera).',
           {'previas': {'formato': 'ida y vuelta', 'diseño_real': 'Q1 12 -> Q2 18 -> Q3 (campeones 12 / principal 14) -> Play-off 24 -> 12 a fase liga',
                        'eliminados_van_a': {'Q1': 'Rising League, Q2 principal', 'Q2': 'Rising League, Q3 principal', 'Q3 campeones': 'Rising League, play-off campeones',
                                             'Q3 principal': 'Rising League, play-off principal', 'Play-off': 'Rising League, fase de liga'}},
            'acceso_directo_fase_liga': 'campeón vigente Rising League, plaza de copa asoc. 1-7, 5º asoc. 1-5, + 11 eliminados de Campions (5 play-off campeones, 2 play-off liga, 4 Q3 liga)',
            'clasifica_a': 'Eurosupercopa y fase de liga de Campions de la temporada siguiente (si no entra por su liga)'}),
 uefa_comp('rising', 'Rising League', 6, '6 bombos de 6 por coeficiente de club. 1 rival de cada bombo (3 en casa, 3 fuera).',
           {'previas': {'caminos': ['campeones', 'principal'], 'formato': 'ida y vuelta',
                        'diseño_real': {'campeones': 'Q2 12 -> Q3 8 -> Play-off 10 -> 5 a fase liga', 'principal': 'Q1 52 -> Q2 86 -> Q3 52 -> Play-off 38 -> 19 a fase liga'}},
            'acceso_directo_fase_liga': 'ninguno por liga; 12 eliminados del play-off de Euroleague',
            'clasifica_a': 'fase de liga de Euroleague de la temporada siguiente (si no entra por su liga)'}),
 {'id': 'eurosupercopa', 'nombre': 'Eurosupercopa', 'confederacion': 'UEFA', 'formato': 'partido único en sede neutral (agosto): campeón de Campions vs campeón de Euroleague. Empate -> penaltis directamente (sin prórroga).'},
 {'id': 'liberadores', 'nombre': 'Liberadores', 'confederacion': 'CONMEBOL', 'temporada': 'febrero-noviembre (año natural)', 'equipos': 47,
  'fase_1': {'equipos': 6, 'formato': 'ida y vuelta, 3 eliminatorias', 'entran': '1 club de BOL, ECU, PAR, PER, URU, VEN', 'ganadores': 'Fase 2', 'perdedores': 'eliminados'},
  'fase_2': {'equipos': 16, 'formato': 'ida y vuelta, 8 eliminatorias', 'entran': '13 directos + 3 ganadores Fase 1', 'ganadores': 'Fase 3', 'perdedores': 'eliminados'},
  'fase_3': {'equipos': 8, 'formato': 'ida y vuelta, 4 eliminatorias', 'ganadores': 'Fase de grupos (4)', 'perdedores': 'Latinoamericana, fase de grupos'},
  'fase_grupos': {'equipos': 32, 'grupos': '8 de 4', 'partidos': '6 (doble vuelta)',
                  'sorteo': '4 bombos de 8 por ranking de clubes (bombo 1: campeón vigente + 7 mejores). No coinciden dos clubes del mismo país en un grupo, salvo los que llegan de la Fase 3.',
                  'clasificacion': {'1º y 2º': 'octavos', '3º': 'play-off de la Latinoamericana', '4º': 'eliminado'}},
  'octavos': 'Sorteo: primeros de grupo (bombo 1) vs segundos (bombo 2); el primero juega la vuelta en casa; no se cruzan equipos del mismo grupo; sí del mismo país. El sorteo fija el cuadro hasta la final.',
  'cuartos_semis': 'ida y vuelta; vuelta en casa del equipo con mejor campaña acumulada desde la fase de grupos',
  'final': 'partido único en sede neutral designada; empate -> prórroga -> penaltis',
  'reglas_eliminatorias': GEN['eliminatoria_ida_vuelta_conmebol'],
  'campeon_vigente': 'Plaza directa en fase de grupos. Si ya está clasificado por su liga (o en temporada 1, que no hay), la plaza pasa al siguiente clasificado no clasificado de su asociación; temporada 1: el 6º de la Liga Brasileña sube a grupos y el resto de plazas brasileñas bajan un puesto.',
  'campeon_latinoamericana': 'Plaza directa en fase de grupos; misma regla de vacante (temporada 1: el 6º de la Liga Argentina sube a grupos y el resto de plazas argentinas bajan un puesto).',
  'clasifica_a': 'Recopa Latina e Intercontinental Planeta'},
 {'id': 'latinoamericana', 'nombre': 'Latinoamericana', 'confederacion': 'CONMEBOL', 'temporada': 'marzo-noviembre', 'equipos': 56,
  'primera_fase': {'equipos': 32, 'formato': 'ida y vuelta (desde 2027), 16 eliminatorias entre clubes del MISMO país (BOL, CHI, COL, ECU, PAR, PER, URU, VEN: 4 clubes cada uno -> 2 cruces por país)'},
  'fase_grupos': {'equipos': 32, 'composicion': '16 ganadores primera fase + 6 BRA + 6 ARG + 4 eliminados Fase 3 de Liberadores', 'grupos': '8 de 4, doble vuelta'},
  'play_off': '8 eliminatorias ida y vuelta: segundos de grupo vs terceros de grupo de Liberadores (el que viene de Liberadores juega la vuelta en casa).',
  'octavos': 'primeros de grupo vs ganadores del play-off; primero de grupo juega la vuelta en casa',
  'cuartos_semis': 'ida y vuelta', 'final': 'partido único en sede neutral; empate -> prórroga -> penaltis',
  'reglas_eliminatorias': GEN['eliminatoria_ida_vuelta_conmebol'],
  'clasifica_a': 'Liberadores (fase de grupos) siguiente y Recopa Latina'},
 {'id': 'recopa_latina', 'nombre': 'Recopa Latina', 'confederacion': 'CONMEBOL', 'formato': 'campeón de Liberadores vs campeón de Latinoamericana, ida y vuelta (febrero); empate global -> penaltis'},
 {'id': 'asia_elite', 'nombre': 'Asia Élite', 'confederacion': 'AFC', 'temporada': 'agosto-mayo',
  'play_off_previo': '4 partidos únicos (2 por región) en casa del mejor clasificado; ganadores a fase de liga. Perdedores eliminados.',
  'fase_liga': {'equipos': 32, 'regiones': 'Oeste 16 y Este 16 (tabla separada por región)', 'partidos': 8,
                'sorteo': '4 bombos de 4 por región según ranking de clubes; 2 rivales de cada bombo (1 casa, 1 fuera); sin rivales de la misma asociación',
                'clasificacion_temporada_1': '1-8 de cada región a octavos',
                'clasificacion_desde_temporada_2': '1-6 a octavos; 7-10 play-off a partido único (7 vs 10 y 8 vs 9, en casa del 7º y 8º)'},
  'octavos': 'dentro de cada región, ida y vuelta: 1-8, 2-7, 3-6, 4-5; vuelta en casa del mejor clasificado',
  'fase_final': 'cuartos, semifinales y final a partido único en una sede centralizada (cuartos: sorteo cruzando Oeste vs Este); empate -> prórroga -> penaltis',
  'clasifica_a': 'Intercontinental Planeta y fase de liga de la temporada siguiente'},
 {'id': 'copa_norte', 'nombre': 'Copa de Campeones del Norte', 'confederacion': 'CONCACAF', 'temporada': 'febrero-mayo',
  'formato_real': '27 clubes; ronda 1 (22 clubes, ida y vuelta) + 5 exentos -> octavos, cuartos, semis ida y vuelta; final a partido único',
  'en_el_juego': 'Solo existen la Liga Norteamericana y la Liga Mexicana: 8 + 8 = 16 clubes -> por reequilibrio todos entran en octavos (la ronda 1 queda vacía).',
  'plazas': {'Liga Norteamericana': 'puestos 1-8 de la clasificación general (si no hay ningún club canadiense, el mejor canadiense sustituye al 8º)', 'Liga Mexicana': 'puestos 1-8 de la tabla anual'},
  'cruces': 'octavos 1-16, 2-15... por ranking de clubes; vuelta en casa del mejor; cuadro fijo',
  'final': 'partido único en el estadio del finalista con mejor rendimiento en el torneo',
  'clasifica_a': 'Intercontinental Planeta (Derbi de las Américas)'},
 {'id': 'africa_masters', 'nombre': 'África Masters', 'confederacion': 'CAF', 'activa': False,
  'motivo': 'En el juego solo hay 2 ligas africanas (Egipcia y Marroquí). Activar cuando haya al menos 8 asociaciones africanas.',
  'formato_real': '2 rondas previas ida y vuelta -> fase de grupos 16 (4 de 4, doble vuelta) -> cuartos, semis y final a ida y vuelta. 12 mejores asociaciones: 2 clubes; resto: 1.'},
 {'id': 'intercontinental', 'nombre': 'Intercontinental Planeta', 'confederacion': 'FIFA', 'temporada': 'anual (diciembre)',
  'formato': ['Derbi de las Américas: campeón Copa de Campeones del Norte vs campeón Liberadores',
              'Copa Desafío: ganador del Derbi vs campeón Asia Élite (y de África Masters si se activa, en una ronda previa)',
              'Final: ganador Copa Desafío vs campeón de Campions'],
  'reglas': 'partidos únicos en sede neutral; empate -> prórroga -> penaltis'},
]

spec = {
 'version': '2026-27 (temporada inicial del juego)',
 'notas': ['Los nombres de las competiciones son inventados. No usar marcas reales en el juego.',
           'Las fases principales (fase de liga, grupos, eliminatorias) reproducen exactamente el formato real. Las rondas previas mantienen sus rondas y caminos reales, pero su tamaño se recalcula porque no todas las asociaciones existen en el juego.'],
 'reglas_generales': GEN,
 'reequilibrio': REBAL,
 'coeficientes': {
  'asociacion_uefa': 'Suma de las 5 últimas temporadas. Puntos de temporada = puntos de todos sus clubes en las 3 competiciones / nº de clubes participantes. Victoria 2, empate 1 (en previas, la mitad); bonus: +4 por jugar fase de liga de Campions, +1 por cada eliminatoria superada desde octavos. Valores iniciales aproximados en "asociaciones".',
  'club': 'Suma de las 5 últimas temporadas con el mismo sistema de puntos. Temporada 1: usar coef_inicial de clubs.json.',
  'plazas_por_rendimiento_EPS': 'Las 2 asociaciones con mejor coeficiente de la temporada anterior obtienen una plaza extra (su 5º) en la fase de liga de Campions. Temporada 1: ' + ' y '.join(EPS_ASSOCS) + '.',
 },
 'asociaciones': [{'codigo': code, 'confederacion': ASSOC_C[1] if (ASSOC_C := next(v for v in ASSOC.values() if v[0] == code)) else None,
                   'ranking_uefa': ASSOC_C[2], 'puntos_iniciales': UEFA_INIT_POINTS.get(ASSOC_C[2]),
                   'region_afc': AFC_REGION.get(code), 'liga_principal': top_league[code]['name'], 'clubes': n_clubs(code),
                   'estado': ('excluida' if code in EXCLUDED else ('parcial' if n_clubs(code) < 8 else 'completa'))}
                  for code in sorted(top_league)],
 'competiciones': COMPS,
 'temporada_1': {
  'uefa_plazas_por_asociacion': uefa_table,
  'uefa_rondas': {c: round_summary(c) for c in ('campions', 'euroleague', 'rising')},
  'euroleague_play_off': season1['euroleague']['po_detalle'],
  'conmebol_plazas_por_asociacion': conmebol_table,
  'afc_plazas_por_asociacion': afc_table,
  'rusia': EXCLUDED['RUS'],
 },
}
json.dump(spec, open(f'{OUT}/competiciones.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)

# ------------------------------------------------------------------ MD
L = []
w = L.append
w('# Competiciones internacionales — especificación para la IA del juego\n')
w('> Documento interno. La columna "Equivalencia real" sirve solo para entender el formato: **nunca debe aparecer en el juego**.\n')
w('| Nombre en el juego | Equivalencia real (solo referencia) | Formato principal |\n|---|---|---|')
for a, b, c in [('Campions', 'UEFA Champions League', '36 en fase de liga, 8 partidos'), ('Euroleague', 'UEFA Europa League', '36 en fase de liga, 8 partidos'),
                ('Rising League', 'UEFA Conference League', '36 en fase de liga, 6 partidos'), ('Eurosupercopa', 'UEFA Super Cup', 'partido único'),
                ('Liberadores', 'CONMEBOL Libertadores', '3 fases previas + 8 grupos de 4'), ('Latinoamericana', 'CONMEBOL Sudamericana', 'primera fase nacional + 8 grupos de 4'),
                ('Recopa Latina', 'Recopa Sudamericana', 'ida y vuelta'), ('Asia Élite', 'AFC Champions League Elite', '2 regiones de 16, 8 partidos'),
                ('Copa de Campeones del Norte', 'Concacaf Champions Cup', 'eliminatorias'), ('África Masters (desactivada)', 'CAF Champions League', 'grupos de 4'),
                ('Intercontinental Planeta', 'FIFA Intercontinental Cup', 'partidos únicos')]:
    w(f'| {a} | {b} | {c} |')
w('\n## 1. Reglas generales\n')
for k, v in GEN.items():
    w(f'- **{k.replace("_", " ")}**: ' + (', '.join(v) if isinstance(v, list) else v))
w('\n## 2. Campions / Euroleague / Rising League (fase principal: formato exacto)\n')
w('| | Campions | Euroleague | Rising League |\n|---|---|---|---|')
w('| Equipos fase de liga | 36 | 36 | 36 |\n| Partidos por equipo | 8 (4 casa / 4 fuera) | 8 | 6 (3 / 3) |')
w('| Bombos | 4 de 9; 2 rivales por bombo | 4 de 9; 2 rivales por bombo | 6 de 6; 1 rival por bombo |')
w('| 1º-8º | Octavos | Octavos | Octavos |\n| 9º-24º | Play-off eliminatorias | Play-off eliminatorias | Play-off eliminatorias |\n| 25º-36º | Eliminados | Eliminados | Eliminados |')
w('\n- Sorteo de fase de liga: sin rivales de la misma asociación; máximo 2 rivales de una misma asociación.')
w('- **Play-off de eliminatorias** (ida y vuelta, vuelta en casa del mejor clasificado): 9/10 vs 23/24 · 11/12 vs 21/22 · 13/14 vs 19/20 · 15/16 vs 17/18 (rival sorteado dentro de cada pareja).')
w('- **Octavos**: 1/2 vs ganador (15/16-17/18) · 3/4 vs ganador (13/14-19/20) · 5/6 vs ganador (11/12-21/22) · 7/8 vs ganador (9/10-23/24).')
w('- Cuadro fijo desde octavos hasta la final: 1º y 2º en mitades opuestas (igual 3º/4º, etc.). En octavos, cuartos y semis la vuelta se juega en casa del mejor clasificado en la fase de liga.')
w('- Final: partido único en sede neutral. Desempates de la tabla: ' + ', '.join(GEN['desempate_fase_liga_uefa']) + '.')
w('\n### Flujo de eliminados entre competiciones (rondas previas)\n')
w('| Eliminado en | Pasa a |\n|---|---|')
for (s, d) in TRANSFERS:
    w(f'| {NAMES[s[0]]} {RN[s[2]]}{PN[s[1]]} | {NAMES[d[0]]} {RN[d[2]]}{PN[d[1]]} |')
w('\n### Acceso real (lista de acceso por defecto 2024-27; ranking de asociaciones 2026-27)\n')
w('- **Campions**, fase de liga directa (29): campeón vigente de Campions, campeón vigente de Euroleague, campeones de las asociaciones 1-10, 2º de la 1-6, 3º de la 1-5, 4º de la 1-4 y 2 plazas EPS.')
w('  - Camino de campeones: campeones 11-14 al play-off; 15-24 a la 2ª previa; 25 en adelante a la 1ª previa → 5 a la fase de liga.')
w('  - Camino de liga: 2º de la 7-9, 3º de la 6 y 4º de la 5 a la 3ª previa; 2º de la 10-15 a la 2ª previa → 2 a la fase de liga.')
w('- **Euroleague**: campeón vigente de Rising, plaza de copa de la 1-7 y 5º de la 1-5 directos. Plaza de copa de la 8-12 al play-off; de la 13-15 a la 3ª previa; de la 16-20, 3º de la 7-12 y 4º de la 6 a la 2ª previa; plaza de copa de la 21-33 a la 1ª previa.')
w('- **Rising League**: 6º de la 1-5 al play-off; plaza de copa de la 34-44, 2º de la 16-33, 3º de la 13-29, 4º de la 7-15 y 5º de la 6 a la 2ª previa; resto a la 1ª previa.')
w('\n## 3. Algoritmo de reequilibrio (asociaciones que no existen en el juego)\n')
w(REBAL['descripcion'] + '\n')
w('```')
for line in REBAL['pseudocodigo']: w(line)
w('```')
w('\n## 4. Temporada 1 — plazas UEFA por asociación (ya calculadas)\n')
w(f'Plazas por rendimiento (EPS) en la temporada 1: {", ".join(EPS_ASSOCS)}. Sin campeones vigentes (sus plazas se reequilibran). Rusia excluida.\n')
w('| Asoc. | Rk | Liga | Puestos de liga → competición (ronda de entrada) |\n|---|---|---|---|')
for t in uefa_table:
    pl = '; '.join(f"{p['puesto_liga']}º {p['competicion']} ({p['entrada']})" for p in t['plazas'])
    w(f"| {t['asociacion']} | {t['ranking']} | {t['liga']} | {pl} |")
w('\n### Tamaño de las rondas previas en la temporada 1 (tras el reequilibrio)\n')
w('"Exentos que suben" = equipos que se saltan esa ronda y entran en la siguiente (o en la fase de liga si es la última ronda del camino). Se eligen por orden de fortaleza.\n')
w('| Competición | Camino | Ronda | Eliminatorias | Exentos que suben |\n|---|---|---|---|---|')
for c in ('campions', 'euroleague', 'rising'):
    for r in round_summary(c):
        w(f"| {NAMES[c]} | {r['camino']} | {RN[r['ronda']]} | {r['eliminatorias']} | {r['exentos_que_suben']} |")
po = season1['euroleague']['po_detalle']
w(f"| Euroleague | (fusión) | Play-off | {po['eliminatorias']} | — |")
w('\n## 5. Liberadores y Latinoamericana (formato exacto)\n')
w('**Liberadores** (47 clubes):\n')
w('1. Fase 1: 6 clubes (BOL, ECU, PAR, PER, URU y VEN), 3 eliminatorias de ida y vuelta → 3 a la Fase 2.')
w('2. Fase 2: 16 clubes (13 directos + 3), 8 eliminatorias → 8 a la Fase 3.')
w('3. Fase 3: 8 clubes, 4 eliminatorias → 4 a la fase de grupos; los 4 eliminados van a la fase de grupos de Latinoamericana.')
w('4. Fase de grupos: 32 clubes, 8 grupos de 4 a doble vuelta. Bombos de 8 por ranking (bombo 1: campeón vigente + 7 mejores). No coinciden dos clubes del mismo país en un grupo, salvo los que llegan de la Fase 3. 1º y 2º → octavos; 3º → play-off de Latinoamericana.')
w('5. Octavos: primeros de grupo vs segundos (el primero juega la vuelta en casa); no se cruzan equipos del mismo grupo. El sorteo fija el cuadro hasta la final. Cuartos y semis: vuelta en casa del de mejor campaña.')
w('6. Final a partido único en sede neutral. En eliminatorias de ida y vuelta: sin valor doble de goles fuera; si hay empate global, penaltis directamente.')
w('\n**Latinoamericana** (56 clubes):\n')
w('1. Primera fase: 32 clubes de BOL, CHI, COL, ECU, PAR, PER, URU y VEN (4 por país), ida y vuelta entre clubes del MISMO país → 16.')
w('2. Fase de grupos: 32 clubes (16 + 6 BRA + 6 ARG + 4 eliminados de la Fase 3 de Liberadores), 8 grupos de 4. 1º → octavos; 2º → play-off.')
w('3. Play-off: 2º de grupo vs 3º de grupo de Liberadores (el de Liberadores juega la vuelta en casa).')
w('4. Octavos: 1º de grupo vs ganador del play-off (el 1º juega la vuelta en casa). Después cuartos y semis de ida y vuelta, y final a partido único en sede neutral.')
w('\n### Plazas por puesto de liga (tabla anual)\n')
w('| Asoc. | Liga | Liberadores grupos | Lib. Fase 2 | Lib. Fase 1 | Latinoamericana |\n|---|---|---|---|---|---|')
for t in conmebol_table:
    def rng(comp, ent):
        ps = [p['puesto_liga'] for p in t['plazas'] if p['competicion'] == comp and p['entrada'] == ent]
        return f'{ps[0]}-{ps[-1]}' if len(ps) > 1 else (str(ps[0]) if ps else '-')
    lat = [p['puesto_liga'] for p in t['plazas'] if p['competicion'] == 'Latinoamericana']
    w(f"| {t['asociacion']} | {t['liga']} | {rng('Liberadores', 'Fase de grupos')} | {rng('Liberadores', 'Fase 2')} | {rng('Liberadores', 'Fase 1')} | {lat[0]}-{lat[-1]} ({CONMEBOL[t['asociacion']]['latino_entrada']}) |")
w('\nCampeón vigente de Liberadores y de Latinoamericana: plaza directa en la fase de grupos de Liberadores. Si ya están clasificados (o en la temporada 1, en la que no hay), la plaza pasa al siguiente clasificado no clasificado de su asociación. En la temporada 1: el 6º de la Liga Brasileña y el 6º de la Liga Argentina suben a la fase de grupos, y todas las plazas inferiores de esas dos ligas bajan un puesto (BRA: Fase 2 = 7º-8º, Latinoamericana = 9º-14º; ARG: Fase 2 = 7º, Latinoamericana = 8º-13º).')
w('\n## 6. Asia Élite (formato exacto 2026-27)\n')
w('- Play-off previo: 4 partidos únicos (2 por región) en casa del mejor clasificado → 2 por región a la fase de liga.')
w('- Fase de liga: 32 clubes, 16 en la región Oeste y 16 en la Este, con una tabla por región. 4 bombos de 4 por región; cada club juega 8 partidos (2 rivales por bombo, 1 en casa y 1 fuera) y nunca contra un club de su asociación.')
w('- Temporada 1: los 8 primeros de cada región van a octavos. Desde la temporada 2: 1º-6º a octavos; 7º-10º juegan un play-off a partido único (7 vs 10, 8 vs 9) en casa del 7º y del 8º.')
w('- Octavos dentro de cada región, a ida y vuelta: 1-8, 2-7, 3-6 y 4-5.')
w('- Fase final centralizada en una sede: cuartos (sorteo Oeste vs Este), semis y final a partido único.')
w('\n### Plazas en la temporada 1 (reparto real 2026-27 reequilibrado: IRN, UZB, IRQ, JOR, MAS y VIE no existen; THA solo tiene 1 club)\n')
w('| Región | Asoc. | Liga | Directos fase liga (puestos) | Play-off (puestos) |\n|---|---|---|---|---|')
for region, rows in afc_table.items():
    for r in rows:
        w(f"| {region} | {r['asociacion']} | {r['liga']} | {r['directos_fase_liga']} ({r['puestos_directos']}) | {r['play_off']} ({r['puestos_play_off']}) |")
w('\nLa Liga India no tiene plaza en Asia Élite (en la realidad juega la competición de segundo nivel).')
w('\n## 7. Otras competiciones\n')
for c in COMPS:
    if c['id'] in ('copa_norte', 'africa_masters', 'intercontinental', 'eurosupercopa', 'recopa_latina'):
        w(f"### {c['nombre']}\n")
        for k, v in c.items():
            if k in ('id', 'nombre'): continue
            if isinstance(v, dict): v = '; '.join(f'{a}: {b}' for a, b in v.items())
            if isinstance(v, list): v = ' → '.join(v)
            w(f'- **{k.replace("_", " ")}**: {v}')
        w('')
w('## 8. Datos que el juego debe guardar\n')
w('- Coeficiente de club (5 temporadas) y de asociación (5 temporadas). Valores iniciales en `clubs.json` (`coef_inicial`) y en `competiciones.json` (`asociaciones[].puntos_iniciales`).')
w('- Campeones vigentes de cada competición.')
w('- Tabla anual de cada liga, que es la que reparte las plazas.')
w('- Parámetro `excluir_rusia` (true por defecto).')
open(f'{OUT}/COMPETICIONES.md', 'w', encoding='utf-8').write('\n'.join(L) + '\n')
print('OK')

# ---- verificación de consistencia de los caminos
def verify(name, solved, entrants_n, target):
    res, q, vac = solved
    ties = sum(r['eliminatorias'] for r in res.values())
    ok = (ties == max(0, entrants_n - target))
    print(f'{name:28} entrantes={entrants_n:3} objetivo={target:3} eliminatorias={ties:3} vacantes={vac} {"OK" if ok else "ERROR"}')
    assert ok
for path in ('campeones', 'liga'):
    n = sum(len(mk('campions', path, r)) for r, _, _ in UEFA['campions']['caminos'][path])
    verify('campions/' + path, season1['campions']['caminos'][path], n, cp_target if path == 'campeones' else lp_target)
verify('euroleague/principal', mp, sum(len(x[2]) for x in mp_rounds), mp_target)
verify('rising/principal', rmp, sum(len(x[2]) for x in mp_r), rmp_target)
print('euroleague PO', season1['euroleague']['po_detalle'], 'cp_in', cp_in)
print('rising directos', rl_direct, 'cp', n_cp, rcp_target)
for r in mp_r: print(' rising', r[0], len(r[2]), rmp[0][r[0]]['eliminatorias'], len(rmp[0][r[0]]['exentos_a_siguiente']), len(rmp[0][r[0]]['participantes']))
