import csv, json, random, hashlib, unicodedata, re, collections as C, os, sys

IN = sys.argv[1]; OUT = sys.argv[2]
os.makedirs(OUT + '/escudos', exist_ok=True)

def H(s):  # hash determinista
    return int(hashlib.md5(s.encode('utf-8')).hexdigest(), 16)

def strip(s):
    return ''.join(c for c in unicodedata.normalize('NFD', s) if unicodedata.category(c) != 'Mn').lower()

# ---------------- MANGLER ISS ----------------
SUB = {'b': 'pv', 'p': 'b', 'd': 't', 't': 'd', 'g': 'k', 'k': 'cg', 'c': 'ks', 'v': 'b', 'l': 'r', 'r': 'l',
       'm': 'ns', 'n': 'm', 's': 'z', 'z': 's', 'j': 'y', 'f': 'v', 'x': 'ks', 'q': 'k', 'w': 'v', 'h': ''}
VOW = {'e': 'i', 'i': 'e', 'o': 'u', 'u': 'o', 'y': 'i', 'é': 'í', 'í': 'é', 'ó': 'ú', 'ú': 'ó'}
BAD = ['puta', 'puto', 'polla', 'cono', 'mierda', 'culo', 'caca', 'pedo', 'nazi', 'fuck', 'shit', 'cock', 'dick',
       'cunt', 'pene', 'teta', 'sexo', 'porn', 'pis', 'kaka', 'mear', 'cago', 'joder', 'nigg', 'fag', 'anus', 'penis',
       'tits', 'rape', 'hitler', 'mongol', 'subnormal', 'marica', 'zorra', 'chocho', 'paja', 'verga', 'pija', 'loser', 'idiot', 'stupid', 'tonto', 'bobo', 'gilip', 'pringa', 'moron', 'dumb', 'gay', 'homo', 'cabr', 'ladron', 'muerto', 'cancer']
KEEP = {'de', 'da', 'do', 'dos', 'das', 'del', 'la', 'le', 'van', 'von', 'der', 'den', 'di', 'du', 'el', 'al', 'ben',
        'bin', 'y', 'e', 'jr', 'jr.', 'sr', 'ii', 'iii', 'mc', 'st', 'st.', 'ter', 'ten', 'af', 'av', 'des', 'dei'}

def lower_map(ch):
    b = strip(ch)
    return b if b else ch

def mangle_core(tok, seed):
    rnd = random.Random(seed)
    s = list(tok)
    lo = [lower_map(c) for c in s]
    # colapsar dobles consonantes (Mbappé -> Mbapé)
    for i in range(len(s) - 1, 0, -1):
        if lo[i] == lo[i - 1] and lo[i] not in 'aeiou' and rnd.random() < .7:
            del s[i]; del lo[i]
    n = len(s)
    cons = [i for i in range(1, n) if lo[i] in SUB and lo[i] != 'h' or (lo[i] == 'h' and i > 1)]
    vows = [i for i in range(1, n) if s[i].lower() in VOW]
    changes = 1 if n <= 4 else 2
    rnd.shuffle(cons)
    done = 0
    for i in cons:
        if done >= changes: break
        opts = SUB[lo[i]]
        new = rnd.choice(opts) if opts else ''
        if new == '' and n <= 4: continue
        s[i] = new.upper() if s[i].isupper() else new
        done += 1
    if (done < changes or rnd.random() < .25) and vows:
        i = rnd.choice(vows); c = s[i]
        s[i] = VOW[c.lower()].upper() if c.isupper() else VOW[c.lower()]
    out = ''.join(s)
    # limpiar secuencias raras
    out = re.sub(r'([bcdfgjklmnpqrstvwxz])\1\1+', r'\1\1', out, flags=re.I)
    out = out.replace('kk', 'k').replace('Kk', 'K')
    return out

TOKMAP = {}
def mangle_tok(tok, ns='p'):
    if not tok or len(tok) <= 2 or strip(tok) in KEEP or not re.search('[A-Za-zÀ-ÿĀ-žА-я]', tok) or tok.isdigit():
        return tok
    key = ns + '|' + tok
    if key in TOKMAP: return TOKMAP[key]
    k = 0
    while True:
        m = mangle_core(tok, H(key + str(k)))
        ok = strip(m) != strip(tok) and len(m) >= 2 and not any(b in strip(m) for b in BAD)
        if ok: break
        k += 1
        if k > 40: m = tok[0] + tok[1:][::-1].lower(); break
    TOKMAP[key] = m
    return m

def mangle(text, ns='p'):
    if not text: return text
    parts = re.split(r"([\s\-']+)", text)
    return ''.join(p if re.fullmatch(r"[\s\-']+", p or ' ') else mangle_tok(p, ns) for p in parts)

CLUBKEEP = {'fc', 'cf', 'sc', 'ac', 'as', 'ssc', 'afc', 'real', 'club', 'atletico', 'atl.', 'united', 'utd', 'city',
            'town', 'rovers', 'wanderers', 'athletic', 'sporting', 'deportivo', 'dep.', 'racing', 'calcio', 'olympique',
            'stade', 'sk', 'fk', 'if', 'bk', 'ik', 'sv', 'vfb', 'vfl', 'tsg', 'cd', 'ud', 'sd', 'rc', 'rcd', 'ca', 'sl',
            'fc.', 'county', 'albion', 'hotspur', 'ath', 'ath.', 'ac.', 'cs', 'us', 'ogc', 'losc', 'aj', 'ajax', 'psv',
            'az', 'ks', 'gks', 'nk', 'hnk', 'sl', 'sc.', 'fsv', 'tsv', 'spvgg', 'sportivo', 'independiente', 'univ.',
            'universidad', 'nacional', 'inter', 'dynamo', 'dinamo', 'spartak', 'lokomotiv', 'olimpia', 'unión', 'union',
            'women', 'ladies', 'femenino', 'féminas', 'feminino', 'w', 'ii', 'b', 'sad', 'cp', 'fcsb', 'osk', 'pfc',
            'cfr', 'csc', 'kaa', 'krc', 'kv', 'kvc', 'rsc', 'sv.', 'and', '&', 'hfc', 'ifk', 'aik', 'fv', 'sk.'}

def mangle_club(name):
    parts = re.split(r"([\s\-'/.]+)", name)
    out = []
    for p in parts:
        if not p or re.fullmatch(r"[\s\-'/.]+", p) or strip(p) in CLUBKEEP or p.isdigit():
            out.append(p)
        else:
            out.append(mangle_tok(p, 'c'))
    return ''.join(out)

# ---------------- LIGAS ----------------
LIGAS = {
 'Premier League': 'Liga Inglesa', 'EFL Championship': 'Liga Inglesa 2', 'EFL League One': 'Liga Inglesa 3',
 'EFL League Two': 'Liga Inglesa 4', 'Barclays WSL': 'Liga Inglesa Femenina',
 'LALIGA EA SPORTS': 'Liga Española', 'LALIGA HYPERMOTION': 'Liga Española 2', 'Liga F Moeve': 'Liga Española Femenina',
 'Bundesliga': 'Liga Alemana', 'Bundesliga 2': 'Liga Alemana 2', '3. Liga': 'Liga Alemana 3', 'GPFBL': 'Liga Alemana Femenina',
 'Serie A Enilive': 'Liga Italiana', 'Serie BKT': 'Liga Italiana 2', 'Calcio A Femminile': 'Liga Italiana Femenina',
 "Ligue 1 McDonald's": 'Liga Francesa', 'Ligue 2 BKT': 'Liga Francesa 2', 'Arkema PL': 'Liga Francesa Femenina',
 'Eredivisie': 'Liga Neerlandesa', 'Nederland Vrouwen Liga': 'Liga Neerlandesa Femenina',
 'Liga Portugal': 'Liga Portuguesa', 'Liga Portugal Feminino': 'Liga Portuguesa Femenina',
 '1A Pro League': 'Liga Belga', 'Scottish Premiership': 'Liga Escocesa', "Scottish Women's League": 'Liga Escocesa Femenina',
 'Trendyol Süper Lig': 'Liga Turca', 'Ö. Bundesliga': 'Liga Austriaca', 'Brack Super League': 'Liga Suiza',
 'Schweizer Damen Liga': 'Liga Suiza Femenina', 'Allsvenskan': 'Liga Sueca', 'Sverige Liga': 'Liga Sueca Femenina',
 'Eliteserien': 'Liga Noruega', 'Norge Kvinner Liga': 'Liga Noruega Femenina', 'Metropolitan Division': 'Liga Danesa',
 'Ekstraklasa': 'Liga Polaca', 'SUPERLIGA': 'Liga Rumana', 'Česká Liga': 'Liga Checa', 'Ceska Liga Žen': 'Liga Checa Femenina',
 'Hellas Liga': 'Liga Griega', 'Ukrayina Liha': 'Liga Ucraniana', 'Liga Hrvatska': 'Liga Croata', 'Liga Cyprus': 'Liga Chipriota',
 'Magyar Liga': 'Liga Húngara', 'Liga Bulgaria': 'Liga Búlgara', 'Liga Azerbaijan': 'Liga Azerí', 'Finnliiga': 'Liga Finlandesa',
 'Iceland League': 'Liga Islandesa Femenina', "SSE Airtricity Men's Premier Division": 'Liga Irlandesa',
 'MLS': 'Liga Norteamericana', 'NWSL': 'Liga Norteamericana Femenina', 'Liga BBVA MX': 'Liga Mexicana',
 'LPF': 'Liga Argentina', 'Liga do Brasil': 'Liga Brasileña', 'Liga Colombia': 'Liga Colombiana',
 'CONMEBOL Libertadores': 'Copa Sudamericana de Campeones', 'CONMEBOL Sudamericana': 'Copa Sudamericana',
 'ROSHN Saudi League': 'Liga Saudí', 'United Emirates League': 'Liga Emiratí', 'CSL': 'Liga China',
 'K League 1': 'Liga Coreana', 'Isuzu UTE A League': 'Liga Australiana', 'ISL': 'Liga India', 'Thailand League': 'Liga Tailandesa',
}

# ---------------- CARGA ----------------
rows = list(csv.DictReader(open(f'{IN}/c34add54-players_clean.csv', encoding='utf-8')))
FIELDS = list(rows[0].keys())
raw = {r['player_id']: r for r in csv.DictReader(open(f'{IN}/cd6d47a8-players.csv', encoding='utf-8'))}
RAW_FIELDS = list(next(iter(raw.values())).keys())
# ================= VARIACIÓN DE MEDIAS / STATS =================
STAT_FIELDS = FIELDS[FIELDS.index('pace'):FIELDS.index('goalkeeping_reflexes') + 1] + ['skill_moves', 'weak_foot']
def perturb(r):
    rnd = random.Random(H('pert' + r['player_id']))
    star = int(r['overall_rating']) >= 88
    d = (lambda: rnd.choice([-1, 1])) if star else (lambda: rnd.choice([-3, -2, -1, 1, 2, 3]))
    o = max(40, min(99, int(r['overall_rating']) + d()))
    p = max(o, min(99, int(r['potential']) + d()))
    r['overall_rating'], r['potential'] = str(o), str(p)
    for f in STAT_FIELDS:
        if r.get(f, '') == '': continue
        if f in ('skill_moves', 'weak_foot'):
            if rnd.random() < .15: r[f] = str(max(1, min(5, int(r[f]) + rnd.choice([-1, 1]))))
            continue
        r[f] = str(max(1, min(99, int(r[f]) + d())))
ORIG_OVR = {r['player_id']: int(r['overall_rating']) for r in rows}
for r in rows: perturb(r)

# ================= LIGAS SUDAMERICANAS =================
SA = {  # clave: (nombre liga, país, XI líder, XI colista, nacionalidad, [clubes por clasificación 2026])
 'BRA1': ('Liga Brasileña', 'Brasil', 77.5, 71.0, 'Brazil', ['Flamengo', 'Palmeiras', 'Athletico Paranaense', 'Fluminense', 'Bahia', 'Cruzeiro', 'Atlético Mineiro', 'Coritiba', 'Red Bull Bragantino', 'Santos', 'São Paulo', 'Vitória', 'Corinthians', 'Botafogo', 'Mirassol', 'Grêmio', 'Vasco da Gama', 'Internacional', 'Remo', 'Chapecoense']),
 'COL1': ('Liga Colombiana', 'Colombia', 73.5, 66.0, 'Colombia', ['Atl. Nacional', 'Deportivo Pasto', 'Once Caldas', 'Junior', 'Deportes Tolima', 'América de Cali', 'Indep. Santa Fe', 'Internacional de Bogotá', 'Deportivo Cali', 'Millonarios', 'Indep. Medellín', 'Águilas Doradas', 'Atlético Bucaramanga', 'Llaneros', 'Fortaleza CEIF', 'Jaguares de Córdoba', 'Alianza Valledupar', 'Boyacá Chicó', 'Cúcuta Deportivo', 'Deportivo Pereira']),
 'URU1': ('Liga Uruguaya', 'Uruguay', 72.0, 65.0, 'Uruguay', ['Peñarol', 'City Torque', 'Deportivo Maldonado', 'Nacional', 'Racing Montevideo', 'Liverpool Montevideo', 'Montevideo Wanderers', 'Albion FC', 'Juventud', 'Central Español', 'Defensor Sporting', 'Cerro Largo', 'Boston River', 'Cerro', 'Progreso', 'Danubio']),
 'PAR1': ('Liga Paraguaya', 'Paraguay', 72.0, 66.0, 'Paraguay', ['Olimpia', 'Club Nacional Asunción', 'Libertad', 'Cerro Porteño', 'Sportivo Trinidense', 'Sportivo Ameliano', '2 de Mayo', 'Guaraní', 'Recoleta', 'Sportivo Luqueño', 'Rubio Ñu', 'Sportivo San Lorenzo']),
 'ECU1': ('Liga Ecuatoriana', 'Ecuador', 72.0, 65.0, 'Ecuador', ['IDV', 'Macar', 'LDU Quito', 'Barcelona SC', 'U. Católica Quito', 'Emelec', 'Aucas', 'Dep. Cuenca', 'Orense', 'Delfín', 'Libertad FC Loja', 'Mushuc Runa', 'Técnico Universitario', 'Guayaquil City', 'Manta', 'Leones del Norte']),
 'CHI1': ('Liga Chilena', 'Chile', 71.5, 65.0, 'Chile', ['Colo-Colo', 'Universidad de Chile', 'Uni. Católica', 'Everton de Viña del Mar', 'Palestino', 'Huachipato', 'Deportes Limache', 'La Serena', 'Coquimbo Unido', 'Deportes Concepción', 'Ñublense', 'Audax Italiano', "O'Higgins", 'Cobresal', 'U. de Concepción', 'Unión La Calera']),
 'PER1': ('Liga Peruana', 'Perú', 71.0, 64.0, 'Peru', ['Alianza Lima', 'Universitario', 'Melgar', 'Deportivo Garcilaso', 'Los Chankas', 'Cusco FC', 'Sporting Cristal', 'Cienciano', 'Alianza Atltico', 'Sport Huancayo', 'Juan Pablo II College', 'Sport Boys', 'Atlético Grau', 'Comerciantes Unidos', 'Deportivo Moquegua', 'FC Cajamarca', 'ADT Tarma', 'UTC Cajamarca']),
 'BOL1': ('Liga Boliviana', 'Bolivia', 69.5, 63.0, 'Bolivia', ['Bolívar', 'Always Ready', 'The Strongest', 'Real Potosí', 'Oriente Petrolero', 'Aurora', 'Guabirá', 'Nacional Potosí', 'Blooming', 'Ind. Petrolero', 'Real Oruro', 'ABB', 'San Antonio Bulo Bulo', 'Universitario de Vinto', 'Real Tomayapo', 'GV San José']),
 'VEN1': ('Liga Venezolana', 'Venezuela', 68.5, 62.0, 'Venezuela', ['Metropolitanos', 'Deportivo Táchira', 'Dep. La Guaira', 'UCV FC', 'Carabobo FC', 'Portuguesa', 'Puerto Cabello', 'Estudiantes de Mérida', 'Caracas FC', 'Monagas', 'Zamora FC', 'Rayo Zuliano', 'Trujillanos', 'Anzoátegui']),
}

# ---- ligas añadidas / completadas (v3) ----
SA.update({
 'Hellas Liga': ('Liga Griega', 'Grecia', 70.0, 63.0, 'Greece', ['Olympiacos FC', 'PAOK FC', 'AEK Athens', 'Panathinaikos', 'Aris', 'OFI', 'Levadiakos', 'Atromitos', 'Asteras Tripolis', 'Volos', 'Panetolikos', 'Kifisia', 'Iraklis', 'Kalamata']),
 'Česká Liga': ('Liga Checa', 'Chequia', 69.0, 62.0, 'Czech Republic', ['Slavia Praha', 'Sparta Praha', 'Viktoria Plzeň', 'Baník Ostrava', 'Slovan Liberec', 'Sigma Olomouc', 'Mladá Boleslav', 'Jablonec', 'Hradec Králové', 'Bohemians 1905', 'Teplice', 'Slovácko', 'Karviná', 'Pardubice', 'Zbrojovka Brno', 'Zlín']),
 'Ukrayina Liha': ('Liga Ucraniana', 'Ucrania', 69.0, 61.0, 'Ukraine', ['Shakhtar Donetsk', 'Dynamo Kyiv', 'Polissya Zhytomyr', 'Kryvbas', 'LNZ Cherkasy', 'Karpaty Lviv', 'Zorya Luhansk', 'Kolos Kovalivka', 'Veres Rivne', 'Metalist 1925', 'Rukh Lviv', 'Obolon Kyiv', 'Epitsentr', 'Kudrivka', 'Bukovyna Chernivtsi', 'Livyi Bereh']),
 'Liga Hrvatska': ('Liga Croata', 'Croacia', 69.0, 63.0, 'Croatia', ['Dinamo Zagreb', 'Hajduk Split', 'Rijeka', 'Varaždin', 'Lokomotiva Zagreb', 'Istra 1961', 'Gorica', 'Slaven Belupo', 'Osijek', 'Šibenik']),
 'Liga Cyprus': ('Liga Chipriota', 'Chipre', 69.0, 60.0, 'Cyprus', ['Omonia FC', 'Pafos FC', 'AEK Larnaca', 'APOEL FC', 'Apollon Limassol', 'Aris Limassol', 'AEL Limassol', 'Anorthosis', 'Olympiakos Nicosia', 'Nea Salamis', 'Omonia Aradippou', 'Omonia 29 Maiou', 'Krasava ENY', 'Karmiotissa']),
 'Magyar Liga': ('Liga Húngara', 'Hungría', 68.0, 61.0, 'Hungary', ['Ferencvárosi TC', 'ETO Győr', 'Paks', 'Puskás Akadémia', 'Debrecen', 'Zalaegerszeg', 'Újpest', 'Kisvárda', 'Vasas', 'MTK Budapest', 'Nyíregyháza', 'Kispest Honvéd']),
 'United Emirates League': ('Liga Emiratí', 'Emiratos Árabes Unidos', 72.0, 61.0, 'United Arab Emirates', ['Al Ain FC', 'Shabab Al Ahli', 'Al Wahda', 'Sharjah', 'Al Jazira', 'Al Wasl', 'Al Nasr Dubai', 'Baniyas', 'Ajman', 'Khor Fakkan', 'Kalba', 'Hatta', 'Dubai United', 'Al Dhafra']),
 'SRB1': ('Liga Serbia', 'Serbia', 74.0, 61.0, 'Serbia', ['Red Star Belgrade', 'Partizan', 'Vojvodina', 'Čukarički', 'Novi Pazar', 'Radnički 1923', 'IMT Beograd', 'Mladost Lučani', 'OFK Beograd', 'Železničar Pančevo', 'Radnik Surdulica', 'Radnički Niš', 'Mačva Šabac', 'Zemun']),
 'RUS1': ('Liga Rusa', 'Rusia', 76.0, 66.0, 'Russia', ['Zenit', 'Krasnodar', 'Spartak Moscow', 'CSKA Moscow', 'Dinamo Moscow', 'Lokomotiv Moscow', 'Rostov', 'Rubin Kazan', 'Baltika', 'Akhmat Grozny', 'Krylia Sovetov', 'Akron Togliatti', 'Dynamo Makhachkala', 'Orenburg', 'Rodina Moscow', 'Fakel Voronezh']),
 'JPN1': ('Liga Japonesa', 'Japón', 73.0, 66.0, 'Japan', ['Kashima Antlers', 'Vissel Kobe', 'Sanfrecce Hiroshima', 'Machida Zelvia', 'Kashiwa Reysol', 'Kawasaki Frontale', 'Urawa Reds', 'Gamba Osaka', 'FC Tokyo', 'Kyoto Sanga', 'Yokohama F. Marinos', 'Cerezo Osaka', 'Nagoya Grampus', 'Avispa Fukuoka', 'Shimizu S-Pulse', 'Fagiano Okayama', 'Tokyo Verdy', 'JEF United Chiba', 'V-Varen Nagasaki', 'Mito HollyHock']),
 'QAT1': ('Liga Catarí', 'Catar', 72.0, 62.0, 'Qatar', ['Al Sadd', 'Al Duhail', 'Al Shamal', 'Al Gharafa', 'Al Rayyan', 'Al Wakrah', 'Al Arabi', 'Qatar SC', 'Al Ahli Doha', 'Al Sailiya', 'Lusail', 'Al Shahania']),
 'EGY1': ('Liga Egipcia', 'Egipto', 72.0, 60.0, 'Egypt', ['Al Ahly', 'Pyramids', 'Zamalek', 'Al Masry', 'Ceramica Cleopatra', 'Smouha', 'ZED FC', 'Modern Sport', 'Enppi', 'El Gouna', 'Talaea El Gaish', 'Petrojet', 'Ghazl El Mahalla', 'Al Mokawloon', 'Wadi Degla', 'Haras El Hodoud', 'National Bank', 'Pharco', 'Kahraba Ismailia', 'Abu Qir Semad']),
 'MAR1': ('Liga Marroquí', 'Marruecos', 70.0, 60.0, 'Morocco', ['RS Berkane', 'AS FAR', 'Wydad AC', 'Raja CA', 'MAS Fès', 'CODM Meknès', 'FUS Rabat', 'Hassania Agadir', 'IR Tanger', 'Difaâ El Jadida', 'Union Touarga', 'KAC Marrakech', 'Renaissance Zemamra', 'Olympique Dcheira', 'Olympic Safi', 'US Yacoub El Mansour']),
})
OPTS = {  # cuota local, extranjeros posibles, pools de nombres, factor de valor
 'EUR': (.72, ['Brazil', 'Portugal', 'Spain', 'France', 'Nigeria', 'Ghana', 'Senegal', 'Croatia', 'Serbia', 'Bosnia and Herzegovina', 'Albania', 'Argentina', 'Colombia', 'Slovakia', 'Poland'], .5),
 'RUS1': (.70, ['Brazil', 'Colombia', 'Serbia', 'Argentina', 'Ukraine', 'Belarus', 'Armenia', 'Iran'], .6),
 'JPN1': (.88, ['Brazil', 'Korea Republic', 'Australia'], .5),
 'GULF': (.45, ['Brazil', 'Morocco', 'Algeria', 'Tunisia', 'Portugal', 'Spain', 'France', 'Argentina', 'Colombia', 'Iran', 'Senegal'], .6),
 'AFR': (.85, ['Ghana', 'Nigeria', 'Senegal', 'Mali', "Côte d'Ivoire", 'Tunisia', 'Algeria', 'Congo DR', 'Cameroon'], .3),
}
REGION = {'RUS1': 'RUS1', 'JPN1': 'JPN1', 'QAT1': 'GULF', 'United Emirates League': 'GULF', 'EGY1': 'AFR', 'MAR1': 'AFR'}
NAME_POOL = {'Qatar': ['Saudi Arabia', 'Qatar'], 'United Arab Emirates': ['Saudi Arabia', 'United Arab Emirates'],
             'Egypt': ['Egypt', 'Saudi Arabia', 'Tunisia', 'Algeria'], 'Russia': ['Russia', 'Belarus', 'Ukraine'],
             'Cyprus': ['Cyprus', 'Greece']}

FOREIGN = ['Argentina', 'Uruguay', 'Colombia', 'Paraguay', 'Venezuela', 'Brazil', 'Chile', 'Ecuador', 'Peru']
VALUE_F = {'BRA1': .7}
for k in SA:
    if k not in VALUE_F and k not in ('BRA1', 'COL1', 'URU1', 'PAR1', 'ECU1', 'CHI1', 'PER1', 'BOL1', 'VEN1'):
        VALUE_F[k] = OPTS[REGION.get(k, 'EUR')][2]
OLD_SA = {'CONMEBOL Libertadores', 'CONMEBOL Sudamericana', 'Liga do Brasil', 'Liga Colombia'}
SA_CAP = 82
for k in OLD_SA: LIGAS.pop(k, None)
for k, v in SA.items(): LIGAS[k] = v[0]
for r in rows:
    if r['league'] in SA: r['playable_league'] = '1'

club2sa = {c: k for k, v in SA.items() for c in v[5]}
for r in rows:
    if r['league'] in OLD_SA:
        k = club2sa[r['club']]  # falla si algún club existente no está mapeado
        r['league'], r['league_country'], r['playable_league'] = k, SA[k][1], '1'

nat_es = {r['nationality']: r['nationality_es'] for r in rows}
pool_first, pool_last, pool_single = C.defaultdict(list), C.defaultdict(list), C.defaultdict(list)
for r in rows:
    if r['generated'] if 'generated' in r else False: continue
    if r['first_name'] and r['last_name'] and r['gender'].startswith('M'):
        pool_first[r['nationality']].append(r['first_name']); pool_last[r['nationality']].append(r['last_name'])
    if r['common_name'] and ' ' not in r['common_name']: pool_single[r['nationality']].append(r['common_name'])
templ_all = C.defaultdict(list)
for r in rows:
    if r['gender'].startswith('M'): templ_all[(r['position'], int(r['overall_rating']))].append(r)
def pick_template(rnd, pos, ovr):
    for d in range(0, 12):
        for o in (ovr - d, ovr + d):
            if templ_all.get((pos, o)): return rnd.choice(templ_all[(pos, o)]), o
    raise ValueError((pos, ovr))

SQUAD = ['GK', 'CB', 'CB', 'LB', 'RB', 'CDM', 'CM', 'CAM', 'LM|LW', 'RM|RW', 'ST',  # titulares
         'GK', 'GK', 'CB', 'CB', 'LB', 'RB', 'CDM', 'CM', 'CM', 'CAM', 'LW|LM', 'RW|RM', 'ST', 'ST']
OFFS = [4, 3, 2, 1, 1, 0, 0, -1, -1, -2, -2] + [-3, -4, -4, -5, -5, -6, -6, -7, -8, -8, -9, -10, -11, -12]
sa_next = 800001
existing = C.defaultdict(list)
for r in rows:
    if r['league'] in SA: existing[(r['league'], r['club'])].append(r)

def gen_player(rnd, key, club, pos, ovr):
    global sa_next
    t, o = pick_template(rnd, pos, ovr)
    if key in REGION or key in OPTS or key not in ('BRA1', 'COL1', 'URU1', 'PAR1', 'ECU1', 'CHI1', 'PER1', 'BOL1', 'VEN1'):
        loc, forn, _ = OPTS[REGION.get(key, 'EUR')]
    else:
        loc, forn = .82, FOREIGN
    nat = SA[key][4] if rnd.random() < loc else rnd.choice([n for n in forn if n != SA[key][4]])
    pools = NAME_POOL.get(nat, [nat])
    pf = [x for n in pools for x in pool_first[n]]; pl = [x for n in pools for x in pool_last[n]]
    if nat == 'Brazil' and rnd.random() < .5 and pool_single[nat]:
        fn, ln, disp = '', '', rnd.choice(pool_single[nat]); cn = disp
    else:
        fn, ln = rnd.choice(pf), rnd.choice(pl); disp = f'{fn} {ln}'; cn = ''
    nr = dict(t)
    f = VALUE_F.get(key, .35)
    nr.update(player_id=str(sa_next), first_name=fn, last_name=ln, common_name=cn, display_name=disp,
              short_name=(f'{fn[0]}. {ln}' if fn else disp), club=club, league=key, league_country=SA[key][1],
              playable_league='1', gender="Men's Football", nationality=nat, nationality_es=nat_es.get(nat, nat),
              contract_until=str(rnd.randint(2026, 2030)), generated='1', origen='liga_sudamericana',
              market_value_eur=str(int(int(t['market_value_eur'] or 0) * f // 1000 * 1000)),
              wage_eur_week=str(int(int(t['wage_eur_week'] or 0) * f // 100 * 100)))
    ORIG_OVR[nr['player_id']] = int(nr['overall_rating'])
    sa_next += 1
    return nr

sa_added = 0
for key, (lname, country, top, bottom, nat, clubs_list) in SA.items():
    n = len(clubs_list)
    for i, club in enumerate(clubs_list):
        rnd = random.Random(H(key + club))
        ex = existing.get((key, club), [])
        if ex:  # club ya existente: completar hasta 23 a su propio nivel
            ov = sorted(int(r['overall_rating']) for r in ex)
            target = round(sum(ov[-11:]) / min(11, len(ov)))
            have = C.Counter(r['position'] for r in ex)
            need = []
            for slot in SQUAD:
                p = slot.split('|')[0]
                if have[p] > 0: have[p] -= 1
                else: need.append(slot)
            need = need[:max(0, 23 - len(ex))]
            offs = [-2, -3, -4, -5, -6, -7, -8, -9] * 4
        else:
            target = round(top - (top - bottom) * i / max(1, n - 1))
            need = list(SQUAD); offs = OFFS
        for j, slot in enumerate(need):
            pos = rnd.choice(slot.split('|'))
            ovr = min(SA_CAP, max(50, target + offs[j % len(offs)] + rnd.choice([-1, 0, 0, 1])))
            rows.append(gen_player(rnd, key, club, pos, ovr)); sa_added += 1
for r in rows:  # tope de 82 en ligas sudamericanas
    if r['league'] in SA and r.get('generated') == '1' and int(r['overall_rating']) > SA_CAP:
        r['overall_rating'] = str(SA_CAP); r['potential'] = str(max(SA_CAP, int(r['potential'])))
for r in rows: r.setdefault('origen', '')
print('SA: jugadores añadidos', sa_added)

miss = set(LIGAS) ^ set(r['league'] for r in rows)
assert not (set(r['league'] for r in rows) - set(LIGAS)), miss

# ---------------- CLUBES ----------------
clubs = {}
for r in rows:
    k = (r['club'], r['league'])
    if k not in clubs:
        clubs[k] = dict(orig=r['club'], league=r['league'], gender='F' if r['gender'].startswith('W') else 'M',
                        country=r['league_country'], playable=r['playable_league'])
# nombre nuevo, único por liga
used = C.defaultdict(set)
for k in sorted(clubs):
    c = clubs[k]
    nm = mangle_club(c['orig'])
    if strip(nm) == strip(c['orig']):  # todo eran siglas/palabras genéricas: forzar la palabra más larga
        toks = [t for t in re.split(r"[\s\-'/.]+", c['orig']) if t and not t.isdigit()]
        t = max(toks, key=len)
        nt = mangle_tok(t, 'cf') if len(t) > 3 else t[:-1] + ('X' if t[-1].upper() != 'X' else 'K')
        nm = c['orig'].replace(t, nt, 1)
    i = 0
    base = nm
    while nm in used[c['league']]:
        i += 1; nm = f"{base} {'ABCDEFG'[i]}"
    used[c['league']].add(nm)
    c['name'] = nm
for i, k in enumerate(sorted(clubs, key=lambda k: (k[1], k[0]))):
    clubs[k]['id'] = f'C{i + 1:04d}'

# ---------------- ESCUDOS ----------------
PAL = ['#C8102E', '#0B3D91', '#FFFFFF', '#111111', '#FFD100', '#00843D', '#6CACE4', '#7A263A', '#F47A20',
       '#5B2C83', '#1D428A', '#E4002B', '#009639', '#002B5C', '#B9975B', '#8A1538', '#00A3E0', '#FFB81C']
SHAPES = {
 'escudo': 'M50 4 L92 14 L92 52 C92 80 70 96 50 104 C30 96 8 80 8 52 L8 14 Z',
 'redondo': 'M50 6 A48 48 0 1 1 49.9 6 Z',
 'clasico': 'M10 8 H90 V60 C90 84 70 98 50 104 C30 98 10 84 10 60 Z',
 'pico': 'M50 2 L94 22 L84 78 L50 104 L16 78 L6 22 Z',
 'ovalo': 'M50 4 C80 4 94 30 94 54 C94 82 74 104 50 104 C26 104 6 82 6 54 C6 30 20 4 50 4 Z',
}
def initials(name):
    w = [x for x in re.split(r"[\s\-./]+", name) if x and not x.isdigit()]
    big = [x for x in w if strip(x) not in CLUBKEEP] or w
    if len(big) >= 2: return (big[0][0] + big[1][0]).upper()
    return big[0][:3].upper()

def crest(c):
    rnd = random.Random(H(c['name'] + c['country']))
    shape = rnd.choice(list(SHAPES))
    a, b = rnd.sample(PAL, 2)
    while a == b or {a, b} <= {'#FFFFFF', '#FFD100', '#FFB81C'}: a, b = rnd.sample(PAL, 2)
    pat = rnd.choice(['liso', 'rayas', 'banda', 'diagonal', 'mitades', 'cuarteles', 'chevron'])
    star = rnd.random() < .25
    ini = initials(c['name'])
    light = lambda col: col in ('#FFFFFF', '#FFD100', '#FFB81C', '#6CACE4', '#B9975B')
    txt = '#111111' if light(a) else '#FFFFFF'
    P = SHAPES[shape]
    pats = {
     'liso': '',
     'rayas': ''.join(f'<rect x="{x}" y="0" width="9" height="110" fill="{b}"/>' for x in range(14, 92, 18)),
     'banda': f'<rect x="0" y="38" width="100" height="26" fill="{b}"/>',
     'diagonal': f'<polygon points="0,20 30,0 100,80 100,110 70,110 0,30" fill="{b}"/>',
     'mitades': f'<rect x="50" y="0" width="50" height="110" fill="{b}"/>',
     'cuarteles': f'<rect x="50" y="0" width="50" height="55" fill="{b}"/><rect x="0" y="55" width="50" height="55" fill="{b}"/>',
     'chevron': f'<polygon points="0,30 50,62 100,30 100,48 50,80 0,48" fill="{b}"/>',
    }
    ring = '#FFFFFF' if not light(a) else '#111111'
    fs = 30 if len(ini) <= 2 else 24
    s = (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 110" width="100" height="110">'
         f'<defs><clipPath id="k"><path d="{P}"/></clipPath></defs>'
         f'<g clip-path="url(#k)"><rect width="100" height="110" fill="{a}"/>{pats[pat]}</g>'
         f'<path d="{P}" fill="none" stroke="{ring}" stroke-width="4"/>'
         f'<path d="{P}" fill="none" stroke="#111111" stroke-width="1" transform="translate(0 0)"/>'
         f'<circle cx="50" cy="56" r="22" fill="{a}" stroke="{ring}" stroke-width="2.5"/>'
         f'<text x="50" y="{56 + fs * .36:.1f}" font-family="Arial Black,Arial,sans-serif" font-weight="900" '
         f'font-size="{fs}" text-anchor="middle" fill="{txt}">{ini}</text>'
         + (f'<polygon points="50,9 53,17 61,17 55,22 57,30 50,25 43,30 45,22 39,17 47,17" fill="#FFD100" stroke="#111" stroke-width=".8"/>' if star else '')
         + '</svg>')
    c.update(color1=a, color2=b, crest_shape=shape, crest_pattern=pat, crest_initials=ini)
    open(f"{OUT}/escudos/{c['id']}.svg", 'w', encoding='utf-8').write(s)

for c in clubs.values(): crest(c)

# ---------------- RENOMBRAR JUGADORES ----------------
NAME_FIELDS = ['common_name', 'first_name', 'last_name', 'display_name', 'short_name']
orig_names = {}
for r in rows:
    orig_names[r['player_id']] = r['display_name']
    for f in NAME_FIELDS: r[f] = mangle(r[f])
    c = clubs[(r['club'], r['league'])]
    r['club'] = c['name']; r['club_id'] = c['id']
    r['league_orig'] = r['league']
    r['league'] = LIGAS[r['league']]
    r['gender'] = 'F' if r['gender'].startswith('W') else 'M'
    r.setdefault('generated', '0')
    if not r['display_name']:
        r['display_name'] = r['common_name'] or f"{r['first_name']} {r['last_name']}".strip()

# ---------------- RELLENO DE PLANTILLAS ----------------
MIN = {'GK': 2, 'CB': 3, 'LB': 1, 'RB': 1, 'MID': 4, 'WIDE': 2, 'ST': 2}
GROUP = {'GK': 'GK', 'CB': 'CB', 'LB': 'LB', 'RB': 'RB', 'CDM': 'MID', 'CM': 'MID', 'CAM': 'MID',
         'LM': 'WIDE', 'RM': 'WIDE', 'LW': 'WIDE', 'RW': 'WIDE', 'ST': 'ST'}
POS_OF = {'GK': ['GK'], 'CB': ['CB'], 'LB': ['LB'], 'RB': ['RB'], 'MID': ['CM', 'CDM', 'CAM'],
          'WIDE': ['RM', 'LM', 'RW', 'LW'], 'ST': ['ST']}
MIN_SQUAD = 18

by_club = C.defaultdict(list)
for r in rows: by_club[r['club_id']].append(r)
templ = C.defaultdict(list)  # (gender,pos,ovr) -> plantillas reales
for r in rows:
    o = int(r['overall_rating'])
    if 65 <= o <= 75: templ[(r['gender'], r['position'], o)].append(r)
names_pool = C.defaultdict(lambda: ([], []))
for r in rows:
    if r['first_name'] and r['last_name']:
        names_pool[(r['nationality'], r['gender'])][0].append(r['first_name'])
        names_pool[(r['nationality'], r['gender'])][1].append(r['last_name'])

rnd = random.Random(2026)
next_id = 900001
added = []
cid2club = {c['id']: c for c in clubs.values()}
for cid, sq in sorted(by_club.items()):
    c = cid2club[cid]
    cnt = C.Counter(GROUP.get(r['position'], 'MID') for r in sq)
    need = []
    for g, m in MIN.items():
        need += [g] * max(0, m - cnt[g])
    total = len(sq) + len(need)
    cyc = ['MID', 'CB', 'WIDE', 'ST', 'GK', 'LB', 'RB']
    i = 0
    while total < MIN_SQUAD:
        need.append(cyc[i % len(cyc)]); i += 1; total += 1
    nats = [r['nationality'] for r in sq] or ['']
    for g in need:
        pos = rnd.choice(POS_OF[g])
        ovr = rnd.randint(65, 75)
        cands = templ.get((c['gender'], pos, ovr)) or templ.get(('M', pos, ovr)) or []
        if not cands:
            for d in range(1, 6):
                cands = templ.get((c['gender'], pos, ovr - d)) or templ.get((c['gender'], pos, ovr + d))
                if cands: break
        t = dict(rnd.choice(cands))
        nat = rnd.choice(nats)
        # nacionalidad coherente con la plantilla
        donor = next((x for x in sq if x['nationality'] == nat), None) or t
        fn_pool, ln_pool = names_pool.get((nat, c['gender'])) or names_pool[(t['nationality'], t['gender'])]
        fn = rnd.choice(fn_pool); ln = rnd.choice(ln_pool)
        fn2 = mangle_tok(fn + 'q', 'g')[:-1] if len(fn) > 3 else fn  # variación extra
        nr = dict(t)
        nr.update(player_id=str(next_id), first_name=fn2, last_name=ln, common_name='',
                  display_name=f'{fn2} {ln}', short_name=f'{fn2[0]}. {ln}', club=c['name'], club_id=cid,
                  league=LIGAS[c['league']], league_orig=c['league'], gender=c['gender'],
                  nationality=nat, nationality_es=donor['nationality_es'], league_country=c['country'],
                  playable_league=c['playable'], contract_until=str(rnd.randint(2027, 2030)), generated='1', origen='relleno_plantilla')
        next_id += 1
        rows.append(nr); sq.append(nr); added.append(nr)

# ---------------- SALIDAS ----------------
OUT_FIELDS = ['player_id', 'club_id'] + [f for f in FIELDS if f != 'player_id'] + ['generated', 'origen']
with open(f'{OUT}/players_clean.csv', 'w', newline='', encoding='utf-8') as f:
    w = csv.DictWriter(f, OUT_FIELDS, extrasaction='ignore'); w.writeheader(); w.writerows(rows)

# players.csv (mismo esquema original; altura/peso siguen vacíos)
with open(f'{OUT}/players.csv', 'w', newline='', encoding='utf-8') as f:
    w = csv.DictWriter(f, RAW_FIELDS, extrasaction='ignore'); w.writeheader()
    for r in rows:
        x = dict(r); x.setdefault('height_cm', ''); x.setdefault('weight_kg', '')
        x['gender'] = "Women's Football" if r['gender'] == 'F' else "Men's Football"
        w.writerow(x)

S = lambda r, k: int(r[k]) if r[k] not in ('', None) else None
search = [dict(id=r['player_id'], name=r['display_name'], ovr=S(r, 'overall_rating'), pos=r['position'], club=r['club'],
               clubId=r['club_id'], league=r['league'], nat=r['nationality'], gender='Women' if r['gender'] == 'F' else 'Men',
               foot=r['preferred_foot'], sm=S(r, 'skill_moves'), wf=S(r, 'weak_foot'), pac=S(r, 'pace'), sho=S(r, 'shooting'),
               pas=S(r, 'passing'), dri=S(r, 'dribbling'), **{'def': S(r, 'defending')}, phy=S(r, 'physicality'),
               acc=S(r, 'movement_acceleration'), spd=S(r, 'movement_sprint_speed'), fin=S(r, 'attacking_finishing'),
               pow=S(r, 'power_shot_power'), vis=S(r, 'mentality_vision'), shortP=S(r, 'attacking_short_passing'),
               longP=S(r, 'skill_long_passing'), ctrl=S(r, 'skill_ball_control'), agi=S(r, 'movement_agility'),
               rea=S(r, 'movement_reactions'), sta=S(r, 'power_stamina'), str=S(r, 'power_strength'),
               tck=S(r, 'defending_standing_tackle'), posn=S(r, 'mentality_positioning'), ps=r['playstyles'])
          for r in sorted(rows, key=lambda r: -int(r['overall_rating']))]
json.dump(search, open(f'{OUT}/players_search.json', 'w', encoding='utf-8'), ensure_ascii=False, separators=(',', ':'))

# clubs.json
cl_out = []
for c in sorted(clubs.values(), key=lambda c: c['id']):
    sq = by_club[c['id']]
    ov = [int(r['overall_rating']) for r in sq]
    top = sorted(sq, key=lambda r: -int(r['overall_rating']))
    cl_out.append(dict(id=c['id'], name=c['name'], league=LIGAS[c['league']], gender=c['gender'], country=c['country'],
                       playable=c['playable'] == '1', players=len(sq), generated=sum(r['generated'] == '1' for r in sq),
                       avg=round(sum(ov) / len(ov), 1), max=max(ov), star=top[0]['display_name'],
                       avg_xi=round(sum(sorted(ov)[-11:]) / 11, 1), crest=f"escudos/{c['id']}.svg",
                       color1=c['color1'], color2=c['color2'], crest_shape=c['crest_shape'],
                       crest_pattern=c['crest_pattern'], initials=c['crest_initials']))
json.dump(cl_out, open(f'{OUT}/clubs.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=0)

# leagues.json
lg = C.defaultdict(list)
for c in cl_out: lg[c['league']].append(c)
lg_out = []
for i, new in enumerate(sorted(set(LIGAS[k] for k in set(r['league_orig'] for r in rows)))):
    cs = lg[new]
    lg_out.append(dict(id=f'L{i + 1:02d}', name=new, country=cs[0]['country'], gender=cs[0]['gender'],
                       playable=cs[0]['playable'], clubs=len(cs), club_ids=[c['id'] for c in cs]))
json.dump(lg_out, open(f'{OUT}/leagues.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)

# top_clubs_rating.json (mismo formato)
real = [c for c in cl_out if c['players'] >= 18]
tops = sorted(real, key=lambda c: -c['avg'])[:30]
json.dump([dict(cl=c['name'], avg=c['avg'], cnt=c['players'], max=c['max'], star=c['star']) for c in tops],
          open(f'{OUT}/top_clubs_rating.json', 'w', encoding='utf-8'), ensure_ascii=False)

# country_data.json (mismo formato)
cd = C.defaultdict(list)
for r in rows: cd[r['nationality']].append(r)
cd_out = []
for nat, ps in sorted(cd.items(), key=lambda t: -len(t[1])):
    top = sorted(ps, key=lambda r: -int(r['overall_rating']))[:5]
    cd_out.append(dict(country=nat, count=len(ps), avg=round(sum(int(r['overall_rating']) for r in ps) / len(ps), 1),
                       men=sum(r['gender'] == 'M' for r in ps), women=sum(r['gender'] == 'F' for r in ps),
                       pos=dict(C.Counter(r['position'] for r in ps).most_common()),
                       top=[dict(n=r['display_name'], r=int(r['overall_rating']), p=r['position']) for r in top],
                       leagues=[dict(l=l, c=n) for l, n in C.Counter(r['league'] for r in ps).most_common(3)],
                       clubs=[dict(cl=l, c=n) for l, n in C.Counter(r['club'] for r in ps).most_common(3)]))
json.dump(cd_out, open(f'{OUT}/country_data.json', 'w', encoding='utf-8'), ensure_ascii=False)

# equivalencias (privado, para depurar; NO distribuir con el juego)
with open(f'{OUT}/_equivalencias_PRIVADO.csv', 'w', newline='', encoding='utf-8') as f:
    w = csv.writer(f); w.writerow(['tipo', 'id', 'original', 'nuevo'])
    for r in rows:
        if r['generated'] == '0': w.writerow(['jugador', r['player_id'], orig_names[r['player_id']], r['display_name']])
    for c in cl_out:
        k = next(k for k, v in clubs.items() if v['id'] == c['id'])
        w.writerow(['club', c['id'], k[0], c['name']])
    for o, n in LIGAS.items(): w.writerow(['liga', '', o, n])

print('jugadores', len(rows), 'añadidos', len(added), 'clubes', len(cl_out), 'ligas', len(lg_out))
print('añadidos por posición', C.Counter(r['position'] for r in added))
